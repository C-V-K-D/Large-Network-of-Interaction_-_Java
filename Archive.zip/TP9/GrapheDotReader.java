import java.util.Vector;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class GrapheDotReader {
    public Graphe graphe;
    //private Vector<Sommet> vectSommets;
        
    public GrapheDotReader(String filename) {
	//graphe = new Graphe();
	//vectSommets = new Vector<>();
	load_dot_file(filename);
    }

    
    public void load_dot_file(String filename) {
	graphe = new Graphe();
	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

	    String line = br.readLine(); //la 1ere ligne correspond au nom du graphe qui ne nous est pas pertinent
	    boolean oriented = false;
	    if(line.split(" ")[0].equals("graph"))
		oriented = false;
	    else
		oriented = true;

	    Sommet sommet = null, voisin = null;
	    	    
	    while( (line = br.readLine()) != null) {
		int idSommet = -1;
		int idVoisin = -1;
	    
		String[] tabLine = line.trim().split(" |->|;|--");

		/*** ON PARSE NOTRE LIGNE POUR RECUPERER LES IDs DU SOMMET ET DU SOMMET VOISIN DE LA LIGNE LUE  ***/
		boolean tour = false;
		for(String current : tabLine) {
		    try {
			int parsedInt = Integer.parseInt(current);
			if(tour == false) {
			    idSommet = parsedInt;
			    tour = true;
			}
			else {
			    idVoisin = parsedInt;
			    tour = false;
			}
		    } catch(NumberFormatException e) { /*System.out.println("Erreur GrapheDotReader.java :\n" + e);*/  }
		}
		if(idSommet != -1) {
		    if(idSommet >= graphe.size() || graphe.get(idSommet) == null) {
			sommet = new Sommet(idSommet);
			graphe.ajouter(idSommet, sommet);
			System.out.println("########### "+idSommet+" "+sommet.id);
		    }
		    else {
			sommet = graphe.get(idSommet);
			System.out.println("XXXXXXXXXXX "+idSommet+" "+sommet.id);
		    }
		    if(idVoisin != -1) {
			if(idVoisin >= graphe.size() || graphe.get(idVoisin) == null) {
			    voisin = new Sommet(idVoisin);
			    graphe.ajouter(idVoisin, voisin);
			    System.out.println("########### "+idVoisin+" "+voisin.id);
			}
			else {
			    voisin = graphe.get(idVoisin);
			    System.out.println("XXXXXXXXXXX "+idVoisin+" "+voisin.id);
			}
			if(oriented) sommet.addVoisin(voisin);
			else sommet.addVoisinNonOriente(voisin);
		    }
		}
	    }//fin while

	    br.close();
	    fr.close();
	} catch(IOException e) { System.out.println(e);	}
    }

}
