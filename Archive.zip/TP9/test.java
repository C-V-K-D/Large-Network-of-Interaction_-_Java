import java.util.Vector;

public class test {
    public static Vector<Character> v;
    public static void main(String[] args) {
	GrapheDotReader gdr = new GrapheDotReader(args[0]);
	System.out.println(gdr.graphe);
    }
	/*v = new Vector<>();
	print();
	v.add('a');
	print();
	v.add('b');
	print();
	v.setElementAt('k', 0);
	print();
    }
    public static void print() {
	System.out.println(v.size() +" "+ v.capacity() +" "+v);
	}*/
}
