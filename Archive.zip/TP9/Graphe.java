import java.util.Vector;
import java.util.Arrays;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Collections;
import java.util.Comparator;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Stack;

//CHANGER LE GRAPHE EN TABLEAU DE SOMMETS (les sommets sont placés dans le tableau à leur indice). CE TABLEAU AURA LA TAILLE DE L'INDICE LE PLUS GRAND D'UN SOMMET
public class Graphe extends Vector<Sommet>{
    public static final String NOM_FICHIER = "graphe";
    public static final String NOM_FICHIER_DOT = "graphe.dot";
    //public int nbArcs = 0; ===> A IMPLEMENTER POUR PLUS D'EFFICACITE ==> REDEFINIR LES METHODES PUT ET REMOVE POUR BIEN MAJ CETTE VARIABLE

    public int nbElementsNonNull = 0;
    
    public Graphe() { super(); }
    public Graphe(int i) { super(i); }
    public Graphe(int i, int j) { super(i, j); }

    public void ajouter(int i, Sommet s) {
	if(i >= this.size()) {
	    this.setSize(i);
	    this.add(i, s);
	}
	else
	    this.setElementAt(s, i);
	nbElementsNonNull++;
    }
    public void retirer(int i) {
	this.insertElementAt(null, i);
	nbElementsNonNull--;
    }


    
    public int getNombreDArcs() {
	int sum = 0;
	for(Sommet s : this)
	    if(s != null)
		sum += s.degSortant;
	return sum;
    }
    public int getNombreDArcsNonOrientes() { return this.getNombreDArcs() / 2; }
    
    public String toString() {
	String str = "";
	for(Sommet s : this)
	    if(s != null)
		str += s.toString();
	return str;
    }
    
    
    /*Deux méthodes pour tester la stabilité du graphe :
     *   - un booléen testant si une modification du graphe a été effectué
     *   - tester la taille du graphe (moins performant selon la manière de la calculer)
     */
    public Graphe extractionKCore(int k) {
	boolean grapheInstable = true;

	while( grapheInstable ) {
	    grapheInstable = false;
	    for(Sommet s : this)
		if(s != null)
		    if(s.degSortant < k) {
			this.retirer(s.id);
			for(Sommet ve : s.voisinsEntrants)
			    ve.removeVoisinSortant(s);
			for(Sommet vs : s.voisinsSortants)
			    vs.removeVoisinEntrant(s);
			grapheInstable = true;
		    }
	}	
	return this;
    }


    public Graphe renumerotation() {
	int cpt = 0;
	for(int i=0 ; i<this.size() ; i++)
	    if(this.get(i) != null)
		this.get(i).id = cpt++;
	return this;
    }


    public float calculDensite() {
	return (float)this.getNombreDArcs() / this.nbElementsNonNull;
    }


    public int coeurDense() {
	int cptKCore = -1;
	int indiceK = 0;
	float densiteMax = 0;

	while(this.nbElementsNonNull != 0 && this.getNombreDArcs() != 0) {
	    /*this = */this.extractionKCore(++cptKCore);
	    float densiteCalculee = this.calculDensite();
	
	    if(densiteCalculee > densiteMax) {
		densiteMax = densiteCalculee;
		indiceK = cptKCore; //indiceK++;
	    }
	} //fin while
	return indiceK;
    }


    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*
    public float calculDiametre() {
	System.out.println("[Graphe.java]: function calculDiametre à MAJ pour s'adapter à une HashMap. Mettre un Parent au sommet pour récupérer le chemin");
	int random = (int)(Math.random() * this.size());
	Sommet randomEdge = this.get(random);

	System.out.println("La fonction de calcul du diamètre n'est malheureusement pas terminée");
	return 0;
    }

    public LinkedList<Sommet> parcoursMax_parcoursLargeur_rec(Sommet initial, int numeroMarquage) {
	LinkedList<Sommet> fifo = new LinkedList<>();
	
	fifo.add(initial);

	while( !fifo.isEmpty() ) {
	    Sommet current = fifo.removeFirst();
	    switch(numeroMarquage) {
	    case 1:
		current.marquage_4_sweep_1 = Sommet.VISITE;
		break;
	    case 2:
		current.marquage_4_sweep_2 = Sommet.VISITE;
		break;
	    case 3:
		current.marquage_4_sweep_3 = Sommet.VISITE;
		break;
	    case 4:
		current.marquage_4_sweep_4 = Sommet.VISITE;
		break;
	    default:
		System.out.println("Graphe.java > parcoursMax_parcoursLargeur_rec > Mauvais numeroMarquage");
		break;
	    }
	    for(Sommet voisin : current.voisinsSortants.values()) {
		switch(numeroMarquage) {
		case 1:
		    if(voisin.marquage_4_sweep_1 == Sommet.NON_VISITE) {
			voisin.marquage_4_sweep_1 = Sommet.SEMI_VISITE;
			fifo.add(voisin);
		    }
		    break;
		case 2:
		    if(voisin.marquage_4_sweep_2 == Sommet.NON_VISITE) {
			voisin.marquage_4_sweep_2 = Sommet.SEMI_VISITE;
			fifo.add(voisin);
		    }
		    break;
		case 3:
		    if(voisin.marquage_4_sweep_3 == Sommet.NON_VISITE) {
			voisin.marquage_4_sweep_3 = Sommet.SEMI_VISITE;
			fifo.add(voisin);
		    }
		    break;
		case 4:
		    if(voisin.marquage_4_sweep_4 == Sommet.NON_VISITE) {
			voisin.marquage_4_sweep_4 = Sommet.SEMI_VISITE;
			fifo.add(voisin);
		    }
		    break;
		default:
		    System.out.println("Graphe.java > parcoursMax_parcoursLargeur_rec > Mauvais numeroMarquage");
		    break;
		}//fin switch
		
	    }//fin for parcours current.voisinsSortants
	}//fin while !fifo.isEmpty()
	return null;
    }
    */
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/


    
    /*** ECRITURE DU GRAPHE DANS UN FICHIER .DOT ***/
    //Ecrit ce graphe dans le fichier "graphe.dot" et renvoie ce nom
    public String ecritureFichierDot(boolean oriented) {
	return ecritureFichierDot("graphe.dot", oriented);
    }
    //Ecrit ce graphe dans le fichier de nom fichierOutput et renvoie ce nom
    public String ecritureFichierDot(String fichierOutput, boolean oriented) {
	HashMap<Integer, ArrayList<Integer>> liaisons = new HashMap<>();
	
	String typeGraph = (oriented) ? "digraph" : "graph";
	//	System.out.println("ECRITURE FICHIER : " + fichierOutput);
		
	try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichierOutput))) {
	    //bw.write(typeGraph + " " + fichierOutput.split("\\.")[0] + " {");
		
	    String nameDigraph = fichierOutput.substring(0, fichierOutput.length() - ".dot".length());
	    bw.write(typeGraph + " " + nameDigraph + " {");
	    bw.newLine();
	    for(Sommet s : this) {
		if(s != null)
		    if(s.voisinsSortants.size() == 0) {
			bw.write(s.id + ";");
			bw.newLine();
		    }
		    else
			for(Sommet vs : s.voisinsSortants) {
			    if(oriented) {
				bw.write(s.id + " -> " + vs.id + ";");
				bw.newLine();
			    }
			    else {
				if(liaisons.get(vs.id) != null) {
				    if( !liaisons.get(vs.id).contains(s.id) ) {
					liaisons.get(vs.id).add(s.id);
					bw.write(s.id + " -- " + vs.id + ";");
					bw.newLine();
				    }
				}
				else {
				    if(liaisons.get(s.id) == null) {
					ArrayList<Integer> liaison_voisins = new ArrayList<>();
					liaison_voisins.add(vs.id);
					liaisons.put(s.id, liaison_voisins);
				    }
				    else
					liaisons.get(s.id).add(vs.id);
				    bw.write(s.id + " -- " + vs.id + ";");
				    bw.newLine();
				}
			    }
			}//fin for(Sommet vs...)
		bw.flush();
	    }
	    bw.write("}");
	    bw.newLine();
	    bw.flush();
	    //bw.close(); //Déjà géré par le try-with-resources => AutoCloseable
	} catch(IOException e) { System.out.println("[Graphe.java]: Erreur lors de l'écriture :\n" + e); }
	return fichierOutput;
    }


    //On ne considère que des distances égales à 1 entre voisins
    public void CentraliteProximite() {
	for(Sommet sommet : this) { //On calcule la centralite de chacun d'eux
	    if(sommet == null) continue;
	    ArrayDeque<Sommet> deque = new ArrayDeque<>();
	    sommet.distanceProximite = 0;
	    deque.add(sommet);

	    while( !deque.isEmpty() ) { //On déroule notre file
		Sommet s = deque.removeFirst();
		s.marquage_centralite = Sommet.VISITE;

		for(Sommet voisin : s.voisinsSortants)
		    if(voisin.marquage_centralite != Sommet.VISITE) {
			voisin.distanceProximite = (s.distanceProximite +1 < voisin.distanceProximite) ? s.distanceProximite +1 : voisin.distanceProximite;
			
			if(voisin.marquage_centralite != Sommet.SEMI_VISITE) {
			    voisin.marquage_centralite = Sommet.SEMI_VISITE;
			    deque.add(voisin);
			}
		    }
	    }

	    // On calcule la centralité de notre sommet et on réinitialise les distances
	    int sum = 0;
	    for(Sommet so : this) {
		if(so == null) continue;
		sum += so.distanceProximite;
		so.marquage_centralite = Sommet.NON_VISITE;
		so.distanceProximite = Integer.MAX_VALUE;
	    }
	    sommet.centralite = (float)this.nbElementsNonNull/sum;
	}
    }

    
    
    //On utilise l'algo de la page en annexe du TP6
    public void CentraliteIntermediarite() {
	for(Sommet s : this) { //On calcule la centralite de chacun d'eux
	    if(s == null) continue;
	    ArrayDeque<Sommet> pile = new ArrayDeque<>(); //l.7
	    ArrayDeque<Sommet> file = new ArrayDeque<>(); //l.8
	    s.nbPCC = 1; //l.9
	    s.distanceIntermediarite = 0; //l.10
	    for(Sommet u : this) { //l.11
		if(u == null) continue;
		if(u != s) {
		    u.betweennessList.clear(); //l.12
		    u.nbPCC = 0; //l.13
		    u.distanceIntermediarite = -1; //l.14
		}
	    }
	    
	    file.add(s); //l.18
	    while( !file.isEmpty() ) { //l.19
		Sommet w = file.removeFirst(); //l.20
		pile.push(w); //l.21
		for(Sommet gammaVoisin : w.voisinsSortants) { //l.22
		    if(gammaVoisin.distanceIntermediarite < 0) { //l.24
			file.add(gammaVoisin); //l.25
			gammaVoisin.distanceIntermediarite = w.distanceIntermediarite +1; //l.26
		    }
		    if(gammaVoisin.distanceIntermediarite == w.distanceIntermediarite +1) { //l.29
			gammaVoisin.nbPCC += w.nbPCC; //l.30
			gammaVoisin.betweennessList.add(w); //l.31
		    } //l.32
		} //l.33
	    } //l.34

	    for(Sommet v : this) //l.35
		if(v != null)
		    if(v != s)
			v.delta = 0; //l.36
	    
	    while( !pile.isEmpty() ){ //l.38
		Sommet w = pile.pop(); //l.39
		for(Sommet v : w.betweennessList) //l.40
		    v.delta += ((float)v.nbPCC / w.nbPCC)*(1 + w.delta); //l.41
		if( w != s) //l.43
		    w.centralite += w.delta;
	    }
	}
    }
    

    

    /*
    //On ne considère que des distances égales à 1 entre voisins
    public void CentraliteProximite() {
	for(Sommet s : this.values()) { //On calcule la centralite de chacun d'eux
	    ArrayDeque<Sommet> deque = new ArrayDeque<>(); 
	    s.distanceProximite = 0;
	    s.valeurPCC.put(s.id, 0);
	    deque.add(s);
	    while( !deque.isEmpty() ) { //On déroule notre file
		Sommet sommet = deque.removeFirst();
		for(Sommet voisin : sommet.voisinsSortants.values()) {
		    Integer distanceVoisin = voisin.valeurPCC.get(s.id);
		    if(distanceVoisin != null) {
			s.valeurPCC.put(voisin.id, distanceVoisin.intValue());
			voisin.distanceProximite = distanceVoisin.intValue();
		    }
		    else {
			voisin.distanceProximite = (sommet.distanceProximite +1 < voisin.distanceProximite) ? sommet.distanceProximite +1 : voisin.distanceProximite;
			voisin.valeurPCC.get(
		    }
		    if(voisin.marquage_centralite == NON_VISITE) {
			voisin.
		    }
		}
	    }
	}
    }
*/
	    
}
