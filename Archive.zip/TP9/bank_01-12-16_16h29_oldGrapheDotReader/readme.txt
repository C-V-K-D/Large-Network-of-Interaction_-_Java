UTILISATION DU PROGRAMME MIS A DISPOSITION :


1. COMPILATION :
   => "javac *.java"


2. EXECUTION :

- ProgrammeBarabasiAlbert :

  	"java ProgrammeBarabasiAlbert"
	      --> Sans argument : Affiche les options disponibles concernant les arguments à fournir au programme

	"java ProgrammeBarabasiAlbert $1 $2 $3 $opt1"
	      avec $1 correspondant à d : le degré de tous nouveaux sommets ajoutés au graphe généré
	      avec $2 correspondant à n0 : le nombre de sommets initiaux
	      avec $3 correspondant à n : le nombre de sommets final du graphe
	      avec $opt1 un argument optionnel devant être :
	           > \"-dir\" : pour obtenir un graphe orienté
	               * Si l'argument n'est pas donné, alors le programme génère un graphe non-orienté par défaut
	  * Exemple : "ProgrammeBarabasiAlbert 10 20 30"
	              "ProgrammeBarabasiAlbert 7 54 72 -dir"

