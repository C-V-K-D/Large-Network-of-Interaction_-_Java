import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

public class GrapheDotReader {

    //public ArrayList<Sommet> graphe;
    public Graphe graphe;
    
    // ====> METTRE EN PLACE CA AVEC LA FONCTION "V putIfAbsent(K key, V value)"
    private HashMap<Integer, Sommet> mapSommets;
    private int maxId = 0;
    
    //hashmap dans laquelle on met l'id du sommet et le sommet
    //entier contenant le plus grand id
    //des qu'on a parcouru tous les sommets (donc quand ils sont tous dans la hashMap avec leurs voisins mis), on cree un tableau de Sommets de la taille du plus grand, et on pose nos sommets dedans
    public GrapheDotReader(String filename) {
	graphe = load_dot_file(filename);
	//mapSommets = new HashMap<>();
    }

    
    public static Graphe load_dot_file(String filename) {
	Graphe grapheReturn = new Graphe();
	
	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

	    String line = br.readLine(); //la 1ere ligne correspond au nom du graphe qui ne nous est pas pertinent
	    boolean oriented = false;
	    if(line.split(" ")[0].equals("graph"))
		oriented = false;
	    else
		oriented = true;

	    Sommet sommetNouveauOuExistant, voisinNouveauOuExistant;
	    	    
	    while( (line = br.readLine()) != null) {
		int idSommet = -1;
		int idVoisin = -1;
	    
		String[] tabLine = line.trim().split(" |->|;|--");

		/*** ON PARSE NOTRE LIGNE POUR RECUPERER LES IDs DU SOMMET ET DU SOMMET VOISIN DE LA LIGNE LUE  ***/
		boolean tour = false;
		for(String current : tabLine) {
		    try {
			int parsedInt = Integer.parseInt(current);
			if(tour == false) {
			    idSommet = parsedInt;
			    tour = true;
			}
			else {
			    idVoisin = parsedInt;
			    tour = false;
			}
		    } catch(NumberFormatException e) { System.out.println("Erreur GrapheDotReader.java :\n" + e);  }
		}
		if(idSommet != -1) {
		    if( (sommetNouveauOuExistant = grapheReturn.get(idSommet)) == null) {
			sommetNouveauOuExistant = new Sommet(idSommet);
			grapheReturn.put(sommetNouveauOuExistant.id, sommetNouveauOuExistant);
		    }
		    if(idVoisin != -1) {
			if( (voisinNouveauOuExistant = grapheReturn.get(idVoisin)) == null) {
			    voisinNouveauOuExistant = new Sommet(idVoisin);
			    grapheReturn.put(voisinNouveauOuExistant.id, voisinNouveauOuExistant);
			}
			if(oriented)
			    sommetNouveauOuExistant.addVoisin(voisinNouveauOuExistant);
			else
			    sommetNouveauOuExistant.addVoisinNonOriente(voisinNouveauOuExistant);
		    }
		}
	    }//fin while

	    br.close();
	    fr.close();
	} catch(IOException e) {
	    System.out.println(e);
	}
	return grapheReturn;
    }


    public static Sommet contains(ArrayList<Sommet> liste, int id) {
	for(Sommet s : liste)
	    if(s.id == id)
		return s;
	return null;
    }
}
