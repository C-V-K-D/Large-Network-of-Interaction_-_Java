import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.util.HashMap;

public class GrapheDotReader {

    //public ArrayList<Sommet> graphe;
    public Graphe graphe;
    
    // ??===> METTRE EN PLACE CA AVEC LA FONCTION "V putIfAbsent(K key, V value)"
    private HashMap<Integer, Sommet> mapSommets;
    private int maxId = 0;
    //hashmap dans laquelle on met l'id du sommet et le sommet
    //entier contenant le plus grand id
    //des qu'on a parcouru tous les sommets (donc quand ils sont tous dans la hashMap avec leurs voisins mis), on cree un tableau de Sommets de la taille du plus grand, et on pose nos sommets dedans
    
    public GrapheDotReader(String filename) {
	mapSommets = new HashMap<>();
	graphe = load_dot_file(filename);
    }

    
    public static Graphe load_dot_file(String filename) {
	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

	    String line = br.readLine(); //la 1ere ligne correspond au nom du graphe qui ne nous est pas pertinent
	    boolean oriented = false;
	    if(line.split(" ")[0].equals("graph"))
		oriented = false;
	    else
		oriented = true;

	    Sommet sommet, voisin;
	    	    
	    while( (line = br.readLine()) != null) {
		int idSommet = -1;
		int idVoisin = -1;
	    
		String[] tabLine = line.trim().split(" |->|;|--");

		/*** ON PARSE NOTRE LIGNE POUR RECUPERER LES IDs DU SOMMET ET DU SOMMET VOISIN DE LA LIGNE LUE  ***/
		boolean tour = false;
		for(String current : tabLine) {
		    try {
			int parsedInt = Integer.parseInt(current);
			if(tour == false) {
			    idSommet = parsedInt;
			    maxId = (idSommet > maxId)? idSommet : maxId;
			    tour = true;
			}
			else {
			    idVoisin = parsedInt;
			    maxId = (idVoisin > maxId)? idVoisin : maxId;
			    tour = false;
			}
		    } catch(NumberFormatException e) { System.out.println("Erreur GrapheDotReader.java :\n" + e);  }
		}
		if(idSommet != -1) {
		    if( (sommet = mapSommets.get(idSommet)) == null ) {
			sommet = new Sommet(idSommet);
			mapSommets.put(idSommet, sommet);
		    }
		    if(idVoisin != -1) {
			if( (voisin = mapSommets.get(idVoisin)) == null ) {
			    voisin = new Sommet(idVoisin);
			    mapSommets.put(idVoisin, voisin);
			}
			if(oriented) sommet.addVoisin(voisin);
			else sommet.addVoisinNonOriente(voisin);
		    }
		}
	    }//fin while

	    br.close();
	    fr.close();
	} catch(IOException e) { System.out.println(e);	}
	
	return new Graphe(maxId, mapSommets);
    }

}
