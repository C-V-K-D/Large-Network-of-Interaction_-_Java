import java.util.HashMap;
import java.util.ArrayList;

public class Sommet {
    public static final char VISITE = 'b';
    public static final char NON_VISITE = 'w';
    public static final char SEMI_VISITE = 'g';

    public int id;
    public ArrayList<Sommet> voisinsSortants;
    public ArrayList<Sommet> voisinsEntrants;
    //    public HashMap<Integer, Sommet> voisinsSortants;
    //    public HashMap<Integer, Sommet> voisinsEntrants;
    //public HashMap<Integer idSommet, Integer valeur> valeurPCC; //pour centralités de proximité et d'intermédiarité // => utile pour une optimisation potentielle
    //public HashMap<Integer idSommet, Integer nombre> nombrePCC; //pour centralité d'intermédiarité seulement // => On suit l'algo de l'annexe pour calculer ça

    public char etat = 'S'; //pour TP9 : epidemie
    public int distanceProximite = Integer.MAX_VALUE; //Utilisé pour le calcul de centralite
    public int distanceIntermediarite = -1;
    public float centralite = 0;
    //public float centraliteIntermediarite = 0;
    public int nbPCC = 0;
    public ArrayList<Sommet> betweennessList;
    public float delta = 0;
    
    public int index = -1;
    public int decouverte = -1;

    public int degSortant = 0;
    public int degEntrant = 0;

    public char marquage = NON_VISITE; //Sert pour Tarjan (CFC)
    public char marquage_4_sweep_1 = NON_VISITE;
    public char marquage_4_sweep_2 = NON_VISITE;
    public char marquage_4_sweep_3 = NON_VISITE;
    public char marquage_4_sweep_4 = NON_VISITE;
    public char marquage_centralite = NON_VISITE;

    public Sommet(int id) {
	this.id = id;
	this.voisinsSortants = new ArrayList<>();
	this.voisinsEntrants = new ArrayList<>();
	//	this.voisinsSortants = new HashMap<>();
	//	this.voisinsEntrants = new HashMap<>();
	//this.valeurPCC = new HashMap<>(); //la distance 0 pour this est mise dans la fonction "CentraliteProximite" de Graphe.java
	//this.nombrePCC = new HashMap<>();
	this.betweennessList = new ArrayList<>();
    }
    /*
    public void addValeurPCCNonOriente(Sommet sommet, int valeur) {
	this.valeurPCC.put(sommet.id, valeur);
	sommet.valeurPCC.put(this.id, valeur);
	//La partie qui suit dépend de l'implémentation du/des Dijkstra
	int ancienNombre;
	int nouveauNombre = ((ancienNombre = this.nombrePCC.get(sommet.id)) == null) ? 1 : ancienNombre +1; //EN CONSIDERANT QU'ON RENTRE LA BONNE VALEUR (on appelle cette fonction qu'une seule fois par paire)
	// +1 ou +combien ? nbDuPere ? Voir le cours du prof
	this.nombrePCC.put(sommet.id, nouveauNombre);
	sommet.nombrePCC.put(this.id, nouveauNombre);
	}*/

    
    public void addVoisinNonOriente(Sommet s) {
	this.voisinsSortants.add(s);
	//	this.voisinsSortants.put(s.id, s);
	this.degSortant++;
	s.degEntrant++;
	s.voisinsSortants.add(this);
	//	s.voisinsSortants.put(this.id, this);
	s.degSortant++;
	this.degEntrant++;
    }
    public void addVoisin(Sommet s) {
	this.voisinsSortants.add(s);
	//	this.voisinsSortants.put(s.id, s);
	this.degSortant++;
	s.voisinsEntrants.add(this);
	//	s.voisinsEntrants.put(this.id, this);
	s.degEntrant++;
    }
    public void removeVoisinEntrant(Sommet s) {
	this.voisinsEntrants.remove(s);
	//	this.voisinsEntrants.remove(s.id);
	this.degEntrant--;
	s.voisinsSortants.remove(this);
	//	s.voisinsSortants.remove(this.id);
	s.degSortant--;
    }
    public void removeVoisinSortant(Sommet s) {
	this.voisinsSortants.remove(s);
	//	this.voisinsSortants.remove(s.id);
	this.degSortant--;
	s.voisinsEntrants.remove(this);
	//	s.voisinsEntrants.remove(this.id);
	s.degEntrant--;
    }

    public String toString() {
	String str = "Sommet "+id+", deg-="+degEntrant+", deg+="+degSortant + "\n";
	for(Sommet s : voisinsSortants)
	    str += "   "+id+" -> "+s.id;
	return str + "\n";
    }
    public void affiche() {
	System.out.println("Sommet "+id+", deg-="+degEntrant+", deg+="+degSortant);
	for(Sommet s : voisinsSortants)
	    System.out.println("   "+id+" -> "+s.id);
	//System.out.println();
    }

    public boolean aucun_voisin_visitable() {
	//	System.out.println("[Sommet.java]: function aucun_voisin_visitable() améliorable en employant une HashMap des voisins visitables: y consacrer du temps plus tard");
	for(Sommet s : voisinsSortants)
	    if(s.marquage == NON_VISITE)
		return false;
	return true;
    }

    public boolean est_non_initialise() {
	return index == -1 || decouverte == -1;
    }
}
