import java.util.Vector;

public class MatAdja extends Vector<Vector<Integer>> {
    public static final int LINKED = 1;
    public static final int NOT_LINKED = 0;
    public static final boolean ORIENTED = true;
    public static final boolean NOT_ORIENTED = false;
    
    public MatAdja() { super(); }

    
    /*** DEBUT : PARTIE FONCTIONS DE RETRAIT DE LIEN ***/
    public void removeLink(int i, int j) { this.removeLink(i, j, NOT_ORIENTED); }
    public void removeLink(int i, int j, boolean oriented) {
	if(oriented == NOT_ORIENTED)
	    this.get(j).setElementAt(NOT_LINKED, i);
	this.get(i).setElementAt(NOT_LINKED, j);
    }
    /*** FIN : PARTIE FONCTIONS DE RETRAIT DE LIEN ***/


    
    /*** DEBUT : PARTIE FONCTIONS D'AJOUT DE LIEN ***/
    //Ajoute basiquement un lien en [i][j] en gerant les null
    private void basicAddLink(int i, int j) {
	//System.out.println("\tbasicAddLink : i="+i+" j="+j+" size="+this.size());
	if(i >= this.size()) {
	    //System.out.println("\t\t0:i >= size : "+i+" >= "+this.size());
	    this.setSize(i);
	    //System.out.println("\t\t1:size="+this.size());
	    this.add(i, new Vector<Integer>());
	    //System.out.println("\t\t2size="+this.size()+" i.size="+this.get(i).size());
	    this.get(i).setSize(j);
	    //System.out.println("\t\t3size="+this.size()+" i.size="+this.get(i).size()+" j="+j);
	    this.get(i).add(j, LINKED);
	}
	else if(this.get(i) == null) {
	    //System.out.println("\t\tthis.get(i) == null");
	    //System.out.println("\t\t0size="+this.size());
	    this.setElementAt(new Vector<Integer>(), i);
	    this.get(i).setSize(j);
	    //System.out.println("\t\t1size="+this.size()+" i.size="+this.get(i).size());
	    this.get(i).add(j, LINKED);
	    //System.out.println("\t\t2size="+this.size()+" i.size="+this.get(i).size());
	}
	else if(j >= this.get(i).size()) {
	    //System.out.println("\t\tj >= this.get(i).size()");
	    this.get(i).setSize(j);
	    this.get(i).add(j, LINKED);
	}
	else {
	    //System.out.println("\t\telse");
	    this.get(i).setElementAt(LINKED, j);
	}
    }
    /* Ajoute l'indication de l'existence d'une arete en [i][j] (ligne, colonne)
     * S'il s'agit d'un graphe non-oriente, on ajoute aussi en [j][i]
     */
    public void addLink(int i, int j) { this.addLink(i, j, NOT_ORIENTED); }
    public void addLink(int i, int j, boolean oriented) {
	//System.out.println("\taddLink");
	if(oriented)
	    this.basicAddLink(i, j);
	else { //NOT_ORIENTED
	    int max = (i > j)? i : j;
	    //System.out.println("\t\tmax="+max+" - size="+this.size());
	    if(max >= this.size())
		this.setSize(max);
	    //System.out.println("\t\tsize="+this.size());
	    this.basicAddLink(i, j);
	    this.basicAddLink(j, i);
	}
    }
    /*** FIN : PARTIE FONCTIONS D'AJOUT DE LIEN ***/


    public boolean checkLink(int i, int j) {
	//Si on regarde en dehors des limites de la matrice, forcement false
	if(i >= this.size() || j >= this.size()) return false;
	//Sinon si la ligne n'a jamais ete initialisee, forcement false
	if(this.get(i) == null) return false;
	//Sinon si ligne dans limite mais colonne hors limite
	else if(j >= this.get(i).size()) return false;
	//Sinon si il n'y a pas d'Integer en [i][j], forcement false
	else if(this.get(i).get(j) == null) return false;
	//Sinon si il y a un Integer en [i][j] et qu'il vaut 1, alors true
	else if(this.get(i).get(j) == LINKED) return true;
	//Sinon false pour tous les autres cas (egal 0 ou n'importe quoi d'autre)
	else return false;
    }

    
    //Il s'agit d'une matrice carree (longueur = largeur)
    //On aurait pu faire une matrice triangulaire pour economiser de la memoire, mais on va la laisser carree pour faciliter l'utilisation de la formule de modularite "plus developpee"
    public int getTaille() { return this.size(); }
}
