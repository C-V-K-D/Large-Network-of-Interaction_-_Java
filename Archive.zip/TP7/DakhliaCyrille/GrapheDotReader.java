import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class GrapheDotReader {
    public Graphe graphe;
    //    private int cpt = 0;
    
    public GrapheDotReader(String filename) { load_dot_file(filename); }

    
    public void load_dot_file(String filename) {
	graphe = new Graphe();
	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

	    String line = br.readLine(); //la 1ere ligne correspond au nom du graphe qui ne nous est pas pertinent
	    boolean oriented = false;
	    if(line.split(" ")[0].equals("graph"))
		oriented = false;
	    else
		oriented = true;
	    Sommet sommet = null, voisin = null;
	    ArrayList<Integer> list = null;
	    while( (line = br.readLine()) != null) {
		//cpt++; //commence ici a 1
		int idSommet = -1;
		int idVoisin = -1;
	    
		String[] tabLine = line.trim().split("[ \t;>-]+");//("[ (->);(--)]+"); //(" |->|;|--");

		/*** ON PARSE NOTRE LIGNE POUR RECUPERER LES IDs DU SOMMET ET DU SOMMET VOISIN DE LA LIGNE LUE  ***/
		boolean tour = false;
		for(String current : tabLine) {
		    try {
			int parsedInt = Integer.parseInt(current);
			if(tour == false) {
			    idSommet = parsedInt;
			    tour = true;
			}
			else {
			    idVoisin = parsedInt;
			    tour = false;
			}
		    } catch(NumberFormatException e) { /*System.out.println("Erreur GrapheDotReader.java :\n" + e);*/  }
		}
		if(idSommet != -1) {
		    //On met a jour le compteur de communautes pour les nouveaux ajouts potentiels de communautes futures
		    graphe.cptCommunautes = (idSommet > graphe.cptCommunautes)? idSommet : graphe.cptCommunautes;

		    if(idSommet >= graphe.size() || graphe.get(idSommet) == null) {
			sommet = new Sommet(idSommet);
			graphe.ajouter(idSommet, sommet);
			//System.out.println("########### "+idSommet+" "+sommet.id);
			//On l'ajoute a la liste des communautes
			list = new ArrayList<>();
			list.add(idSommet);
			graphe.listeCom.add(list);
			//On ecrit la communaute a laquelle ce sommet appartient
			if(idSommet >= graphe.communautes.size()) {
			    graphe.communautes.setSize(idSommet);
			    graphe.communautes.add(idSommet, idSommet);
			}
			else if(graphe.communautes.get(idSommet) == null)
			    graphe.communautes.setElementAt(idSommet, idSommet);
			else {
			    System.out.println("Warning: reecriture d'une communaute pour le sommet "+idSommet);
			    graphe.communautes.setElementAt(idSommet, idSommet);
			}
		    }
		    else {
			sommet = graphe.get(idSommet);
			//System.out.println("XXXXXXXXXXX "+idSommet+" "+sommet.id);
		    }
		    if(idVoisin != -1) {
			//On met a jour le compteur de communautes pour les nouveaux ajouts potentiels de communautes futures
			graphe.cptCommunautes = (idVoisin > graphe.cptCommunautes)? idVoisin : graphe.cptCommunautes;
			
			if(idVoisin >= graphe.size() || graphe.get(idVoisin) == null) {
			    voisin = new Sommet(idVoisin);
			    graphe.ajouter(idVoisin, voisin);
			    //System.out.println("########### "+idVoisin+" "+voisin.id);
			    //On l'ajoute a la liste des communautes
			    list = new ArrayList<>();
			    list.add(idVoisin);
			    graphe.listeCom.add(list);
			    //On ecrit la communaute a laquelle ce sommet appartient
			    if(idVoisin >= graphe.communautes.size()) {
				graphe.communautes.setSize(idVoisin);
				graphe.communautes.add(idVoisin, idVoisin);
			    }
			    else if(graphe.communautes.get(idVoisin) == null)
				graphe.communautes.setElementAt(idVoisin, idVoisin);
			    else {
				System.out.println("Warning: reecriture d'une communaute pour le sommet "+idVoisin);
				graphe.communautes.setElementAt(idVoisin, idVoisin);
			    }
			}
			else {
			    voisin = graphe.get(idVoisin);
			    //System.out.println("XXXXXXXXXXX "+idVoisin+" "+voisin.id);
			}
			if(oriented) {
			    sommet.addVoisin(voisin);
			    graphe.matAdja.addLink(idSommet, idVoisin, true); //true:oriented
			}
			else {
			    sommet.addVoisinNonOriente(voisin);
			    graphe.matAdja.addLink(idSommet, idVoisin, false); //false:not_oriented
			}
			graphe.nbArcsInit++;
		    }
		}
	    }//fin while

	    br.close();
	    fr.close();
	} catch(IOException e) { System.out.println(e);	}
    }

}
