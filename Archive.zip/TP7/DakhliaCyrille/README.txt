UTILISATION DU PROGRAMME MIS A DISPOSITION :


1. COMPILATION :
   => "javac *.java"


2. EXECUTION :

- ProgrammeModularite :
  	--> Lancez le programme sans argument pour afficher l'aide aux arguments

- ProgrammeAlgoNewman :
  	--> Lancez le programme sans argument pour afficher l'aide aux arguments
