import java.util.Vector;
import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class CommunityReader {
    public ArrayList<ArrayList<Integer>> listeCom;
    public Vector<Integer> communautes;
    private int cpt = 0;
    
    public CommunityReader(String filename) { load_community_file(filename); }

    
    public void load_community_file(String filename) {
	listeCom = new ArrayList<ArrayList<Integer>>();
	communautes = new Vector<>();
	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

	    String line; int parsedInt; ArrayList<Integer> list = null;
	    while( (line = br.readLine()) != null) {
		cpt++; //commence ici a 1
		String[] tabLine = line.trim().split("[ \t\f\r]+"); //(" |->|;|--|\t");
		if(list != null)
		    listeCom.add(list);
		list = new ArrayList<>();
		for(String current : tabLine)
		    try {
			parsedInt = Integer.parseInt(current);
			if(parsedInt >= communautes.size()) {
			    communautes.setSize(parsedInt);
			    communautes.add(parsedInt, cpt);
			}
			else if(communautes.get(parsedInt) == null)
			    communautes.setElementAt(cpt, parsedInt);
			else {
			    System.out.println("Parsing community: valeur ecrasee => fichier erronee: contient des doublons");
			    communautes.setElementAt(cpt, parsedInt);
			}
			list.add(parsedInt);
		    } catch(NumberFormatException e) { /*System.out.println("Erreur CommunityReader.java :\n" + e);*/  }
	    }//fin while
	    listeCom.add(list); //pour ajouter la derniere communaute de la boucle
	    System.out.println("Nb communautes="+cpt);
	    br.close();
	    fr.close();
	} catch(IOException e) { System.out.println(e);	}
    }
}
