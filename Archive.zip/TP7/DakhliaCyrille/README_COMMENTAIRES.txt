Bonjour,

Je vous écris ce commentaire afin de vous apporter quelques précisions sur mes résultats :

Partie 1 : Calcul de modularité
       -> avec la définition simplifiée, j'obtiens un BON RESULTAT pour le graphe1000sommets, mais des valeurs ELOIGNEES pour grapheClubKarate
       -> avec la définition plus développée, j'obtiens une valeur ELOIGNEE pour le graphe1000sommets, mais des valeurs PROCHES pour grapheClubKarate

Partie 2 : Algorithme de Newman
       - avec la définition simplifiée, j'obtiens un résultat PLUTOT ELOIGNE
       - avec la définition plus développée, j'obtiens un résultat TRES PROCHE
