import java.util.Vector;
import java.util.ArrayList;
public class ProgrammeModularite {
    
    public static void main(String[] args) {
	if(args.length != 0 && args.length != 2 && args.length != 3)
	    perror("Erreur sur le nombre d'argument.");
	else if(args.length == 0)
	    printHelp();
	else {
	    boolean verbose = false;
	    if(args.length == 2) verbose = false;
	    else if(args.length == 3 && !args[2].equals("-v"))
		perror("Erreur sur l'argument. \"-v\" pour l'option verbose");
	    else verbose = true;
	    
	    GrapheDotReader gdr = new GrapheDotReader(args[0]);
	    CommunityReader cr = new CommunityReader(args[1]);
	    Graphe g = gdr.graphe;
	    Vector<Integer> com = cr.communautes;
	    ArrayList<ArrayList<Integer>> listeCom = cr.listeCom;
	    //System.out.println("com:"+com);
	    //System.out.println("g:"+g);
	    //System.out.println("listeCom.size()="+listeCom.size());
	    System.out.println("m="+g.nbArcsInit);
	    System.out.println("Calcul en cours...");
	    System.out.println("Calcul modularité développée : "+calculModularite(g, com, verbose));
	    System.out.println("Calcul modularité simple : "+calculModulariteSimple(g, listeCom));
	}//fin else args.length
    }//fin main


    //Renvoie la modularite (entre -1 et 1) du graphe donne en argument selon le decoupage des communautes aussi donne en argument
    public static float calculModularite(Graphe g, Vector<Integer> com, boolean verbose) {
	float result = 0;
	for(Sommet u : g)
	    if(u != null)
		for(Sommet v : g) {
		    if(v != null) {
			if(u != v) { //continue; //ON NE PREND PAS EN COMPTE LES DOUBLONS,NON?
			    if(verbose)
				System.out.println("u.id="+u.id+" v.id="+v.id+" size="+com.size());
			    if(com.get(u.id) == com.get(v.id)) { //delta de Kronecker
				if(verbose) {
				    System.out.println("\tMEME COM");
				//result += (u.voisinsSortants.contains(v))? 1 : 0;
				    System.out.println("\t0:result="+result);
				}
				result += (g.matAdja.checkLink(u.id, v.id))? 1 : 0;
				if(verbose) {
				    System.out.println("\t1:result="+result);
				    System.out.println("\tdu="+u.degSortant+" dv="+v.degSortant);
				}
				result -= (float)(u.degSortant * v.degSortant)/(2*g.nbArcsInit);
				if(verbose)
				    System.out.println("\t2:result="+result);
			    }
			}
		    }
		}
	result = result/(2*g.nbArcsInit);
	return result;
    }


    public static float calculModulariteSimple(Graphe g, ArrayList<ArrayList<Integer>> listeCom) {
	float result = 0;
	for(ArrayList<Integer> liste : listeCom)
	    result += eccPrime(g, liste, liste) - Math.pow(ac(g, liste), 2);
	return result;
    }
    public static float eccPrime(Graphe g, ArrayList<Integer> comA, ArrayList<Integer> comB) {
	float result = 0;
	for(int idA : comA)
	    for(int idB : comB) {
		if(idA == idB) continue;
		result += (g.matAdja.checkLink(idA, idB))? 1 : 0;
	    }
	return result/g.nbArcsInit;
    }
    public static float ac(Graphe g, ArrayList<Integer> com) {
	float result = 0;
	for(int id : com)
	    for(int i=0 ; i<g.matAdja.size() ; i++)
		result += (g.matAdja.checkLink(id, i))? 1 : 0;
	return result/g.nbArcsInit;
    }
    

    /*************************************************
     ********* FONCTION DE GESTION DU PROGRAMME ******
     *************************************************/
    private static void perror(String msg) {
	System.out.println(msg);
	System.exit(0);
    }
    private static void printHelp() {
	System.out.println("Bienvenue dans l'assistance au calcul de la modularité !\n" +
			   "  Veuillez trouver ci-après les détails d'utilisation de notre programme !\n" +
			   "    Bonne modularité !\n\n" +
			   " -----> Liste des arguments <-----\n" +
			   "  * Sans argument : c'est ce que vous venez de faire pour afficher ce message d'assistance à l'utilisation de notre programme !\n" +
			   "  * multi-arguments :\n" +
			   "      java ProgrammeModularite $1 $2 $opt1\n" +
			   "         avec $1 correspondant au fichier du graphe au format \"dot\"\n" +
			   "         avec $2 correspondant au fichier du découpage des communautés\n" +
			   "         avec $opt1 : \"-v\" pour l'option verbose (optionnel)\n" +
			   "  * Exemple : \"ProgrammeModularite graphe.dot communities.txt\"\n");
    }
}
