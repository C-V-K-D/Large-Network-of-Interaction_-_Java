public class Parcours {

    public static void main(String[] args) {
	if(args.length != 2) {
	    System.out.println("Erreur sur le nombre d'argument");
	    System.exit(0);
	}
	else {
	    GrapheDotReader gdr = new GrapheDotReader(args[0]);
	    int idSommetOrigine = -1;
	    try { idSommetOrigine = Integer.parseInt(args[1]); } catch(NumberFormatException e) { System.out.println(e); }
	    Sommet sommetOrigine = gdr.GDR_contains(idSommetOrigine);

	    if(sommetOrigine == null) {
		System.out.println("Ce sommet n'existe pas dans le graphe");
		System.exit(0);
	    }
	    else
		System.out.println(nb_sommets_accessibles_parcours_profondeur_rec(sommetOrigine));
	    
	}
    }


    public static int nb_sommets_accessibles_parcours_profondeur_rec(Sommet initial) {
	initial.marquage = Sommet.VISITE;
	
	if(initial.aucun_voisin_visitable()) {
	    return 1;
	}
	else {
	    int[] somme_sommets = new int[initial.voisins.size()]; //tableau initialise a 0 en java

	    for(int i=0 ; i<initial.voisins.size() ; i++) {
		Sommet s = initial.voisins.get(i);
		if(s.marquage == Sommet.NON_VISITE) {
		    s.marquage = Sommet.SEMI_VISITE;
		    somme_sommets[i] = nb_sommets_accessibles_parcours_profondeur_rec(s);
		}
	    }
	    int somme = 0;
	    for(int i=0 ; i<somme_sommets.length ; i++)
		somme += somme_sommets[i];
	    return 1 + somme;
	}
    }
    
}
