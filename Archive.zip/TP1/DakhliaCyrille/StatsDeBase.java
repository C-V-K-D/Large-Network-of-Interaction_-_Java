import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class StatsDeBase {

    public static void main(String[] args) {
	if(args.length != 1) {
	    System.out.println("Erreur sur le nombre d'argument");
	    System.exit(0);
	}
	else {
	    GrapheDotReader gdr = new GrapheDotReader(args[0]);
	    
	    int n_nbSommets, m_nbArcs, degSortantMax, degEntrantMax, numSommetMax;

	    n_nbSommets = gdr.graphe.size();
	    m_nbArcs = degSortantMax = degEntrantMax = numSommetMax = 0;
	    for(Sommet s : gdr.graphe) {
		m_nbArcs += s.degSortant;
		degSortantMax = (s.degSortant > degSortantMax)? s.degSortant : degSortantMax;
		degEntrantMax = (s.degEntrant > degEntrantMax)? s.degEntrant : degEntrantMax;
		numSommetMax = (s.id > numSommetMax)? s.id : numSommetMax;
	    }
	    
	    System.out.println(n_nbSommets+" "
			       +m_nbArcs+" "
			       +degSortantMax+" "
			       +degEntrantMax+" "
			       +numSommetMax);
	}
    }

}
    
    
