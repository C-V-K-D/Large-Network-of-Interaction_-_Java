import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class GrapheDotReader {

    public ArrayList<Sommet> graphe;

    public GrapheDotReader(String filename) {
	graphe = load_dot_file(filename);
    }

    
    public static ArrayList<Sommet> load_dot_file(String filename) {
	ArrayList<Sommet> sommetsReturn = new ArrayList<>();

	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

			
	    String line = br.readLine(); //la 1ere ligne correspond au nom du graphe qui ne nous est pas pertinent

	    ArrayList<Sommet> adjacents = new ArrayList<>();
	    
	    int idSommet = -1;
	    int newIdSommet = -1;
	    int newIdVoisin = -1;
	    Sommet nouveauSommet, sommetExistant;
	    	    
	    while( (line = br.readLine()) != null) {
				
		String[] tabLine = line.trim().split(" |->|;");

		/*** TEST DU CAS OU LE FICHIER EST VIDE, OU SI ON LIT LA DERNIERE LIGNE ***/
		if(tabLine[0].equals("}")) { //Cas derniere ligne lue
		    if( idSommet != -1 ) { //si le fichier dot est vide, on n'ajoute rien...
			if( (sommetExistant = contains(sommetsReturn, idSommet)) != null) //...sinon c'est qu'on a deja parcouru au moins 1 sommet qu'il faut ajouter
			    sommetExistant.setVoisins(adjacents);
			else {
			    nouveauSommet = new Sommet(idSommet, adjacents);
			    sommetsReturn.add(nouveauSommet);
			}
			break;
		    }
		}
		    
		    
		/*** ON PARSE NOTRE LIGNE POUR RECUPERER LES IDs DU SOMMET ET DU SOMMET VOISIN DE LA LIGNE LUE  ***/
		boolean tour = false;
		for(String current : tabLine) {
		    try {
			int parsedInt = Integer.parseInt(current);
			if(tour == false) {
			    newIdSommet = parsedInt;
			    tour = true;
			}
			else {
			    newIdVoisin = parsedInt;
			    tour = false;
			}
		    } catch(NumberFormatException e) {  }
		}


		/*** SI L'ID DU SOMMET DE LA LIGNE PRECEDENTE ET CELUI DE LA LIGNE COURANTE SONT DIFFERENTS, C'EST QU'ON A AFFAIRE A UN NOUVEL ID, et donc il faut creer le sommet correspondant a la ligne precedente  ***/
		if( newIdSommet != idSommet && idSommet != -1 ) {
		    //On verifie qu'on n'a pas deja cree notre sommet precedemment, auquel cas on le recupere...
		    if( (sommetExistant = contains(sommetsReturn, idSommet)) != null)
			sommetExistant.setVoisins(adjacents);
		    //...sinon on le cree*/
		    else {
			nouveauSommet = new Sommet(idSommet, adjacents);
			sommetsReturn.add(nouveauSommet);
		    }
		    //on reinitialise nos variables
		    adjacents = new ArrayList<>();
		}


		/*** Ajout des voisins dans la liste d'adjacence ***/
		if(tabLine.length > 1) {//Pour l'ajout des voisins des sommets qui en ont ("4;" n'en a pas)
		    if( (sommetExistant = contains(sommetsReturn, newIdVoisin)) != null)
			adjacents.add(sommetExistant);
		    else {
			nouveauSommet = new Sommet(newIdVoisin, new ArrayList<Sommet>());
			sommetsReturn.add(nouveauSommet);
			adjacents.add(nouveauSommet);
		    }
		}

		    
		/*** On n'oublie pas de mettre a jour nos variables ***/
		idSommet = newIdSommet;
		    
	    }//fin while

	    br.close();
	    fr.close();
	} catch(IOException e) {
	    System.out.println(e);
	}
	return sommetsReturn;
    }


    public Sommet GDR_contains(int id) {
	for(Sommet s : graphe)
	    if(s.id == id)
		return s;
	return null;
    }
    public static Sommet contains(ArrayList<Sommet> liste, int id) {
	for(Sommet s : liste)
	    if(s.id == id)
		return s;
	return null;
    }
}
