import java.util.ArrayList;

public class Sommet {

    public int id;
    public ArrayList<Sommet> voisins;

    public int degSortant;
    public int degEntrant;

    public char marquage;
    public static final char VISITE = 'b';
    public static final char NON_VISITE = 'w';
    public static final char SEMI_VISITE = 'g';
    
    public Sommet(int id, ArrayList<Sommet> listeVoisins) {
	this.id = id;
	voisins = listeVoisins;
	degSortant = listeVoisins.size();
	degEntrant = 0;
	for(Sommet s : listeVoisins)
	    s.degEntrant++;
	marquage = NON_VISITE;
    }

    public void setVoisins(ArrayList<Sommet> listeVoisins) {
	voisins = listeVoisins;
	degSortant = listeVoisins.size();
	for(Sommet s : listeVoisins)
	    s.degEntrant++;
    }

    public void affiche() {
	System.out.println("Sommet "+id+", deg-="+degEntrant+", deg+="+degSortant);
	for(Sommet s : voisins)
	    System.out.println("   "+id+" -> "+s.id);
	//System.out.println();
    }

    public boolean aucun_voisin_visitable() {
	for(Sommet s : voisins)
	    if(s.marquage == NON_VISITE)
		return false;
	return true;
    }
}
