UTILISATION DES PROGRAMMES MIS A DISPOSITION :


1. COMPILATION :
   => "javac *.java"


2. EXECUTION :

- StatsDeBase.java :
   	"java StatsDeBase $1"
	      avec $1 correspondant au nom du fichier d'extension ".dot"

- Parcours.java :
  	"java Parcours $1 $2"
	      avec $1 correspondant au nom du fichier d'extension ".dot"
	      	   $2 correspondant au numero du sommet d'origine du parcours
