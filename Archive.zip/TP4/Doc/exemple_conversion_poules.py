import os

f = open("poules.dat", "r")
i = 0
print "digraph poules {"
for line in f:
	j = 0
	s = line.split(" ")
	for u in s:
		if(u == "1"):
			print "\t",i," -> ",j,";"
		j+=1
	i+=1
print "}"
f.close()