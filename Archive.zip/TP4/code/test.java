public class test {
    public static void main(String[] args) {
	//String s = "1        2          3 4           5";
	String s = "30	141230	3352";

	System.out.println("s=" + s + "|");

	String[] tab = s.split(" |\t");
	System.out.println("tab.length = " + tab.length);
	for(String str : tab)
	    if(!str.equals(""))
		System.out.println("  " + str +"|");
    }
}
