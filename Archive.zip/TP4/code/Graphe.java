import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class Graphe extends ArrayList<Sommet> {

    public Graphe() {
	super();
    }

    public int getNombreDArcs() {
	int sum = 0;
	for(Sommet s : this)
	    sum += s.degSortant;
	return sum;
    }

    public String toString() {
	String str = "";
	for(Sommet s : this)
	    str += s.toString();
	return str;
    }
    
    /*Deux méthodes pour tester la stabilité du graphe :
     *   - un booléen testant si une modification du graphe a été effectué
     *   - tester la taille du graphe (moins performant selon la manière de la calculer)
     */
    public Graphe extractionKCore(int k) {
	boolean grapheInstable = true;
	ArrayList<Sommet> sommetsASupprimer = new ArrayList<Sommet>();

	while( grapheInstable ) {
	    grapheInstable = false;
	    for(Sommet s : this) {
		if(s.degSortant < k) {
		    sommetsASupprimer.add(s);
		    for(Sommet ve : s.voisinsEntrants)
			ve.removeVoisinSortant(s);
		    for(Sommet vs : s.voisinsSortants)
			vs.removeVoisinEntrant(s);
		}
	    }
	    for(Sommet s : sommetsASupprimer) {
		this.remove(s);
		grapheInstable = true;
	    }
	    sommetsASupprimer.clear();
	}	
	return this;
    }


    public Graphe renumerotation() {
	Collections.sort(this, new Comparator<Sommet>() {
		public int compare(Sommet s1, Sommet s2) {
		    return ((Integer)(s1.id)).compareTo((Integer)(s2.id));
		}
	    });
	int cpt = 0;
	for(Sommet s : this)
	    s.id = cpt++;
	return this;
    }


    public float calculDensite() {
	return (float)this.getNombreDArcs() / this.size();
    }

}
