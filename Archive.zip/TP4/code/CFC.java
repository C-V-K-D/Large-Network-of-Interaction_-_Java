import java.util.ArrayList;

public class CFC extends ArrayList<Sommet> {

    public CFC() {
	super();
    }

}
