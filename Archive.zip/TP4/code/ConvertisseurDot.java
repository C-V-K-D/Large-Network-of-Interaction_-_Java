import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.FileNotFoundException;

public class ConvertisseurDot {

    public static void main(String[] args) {
	if(args.length != 1) {
	    System.out.println("Erreur sur le nombre d'argument");
	    System.exit(0);
	}
	else {
	    if(args[0].substring(args[0].length() -4).equals(".dat"))
		datToDot(args[0]);
	    else if(args[0].substring(args[0].length() - 6).equals(".edges"))
		edgesToDot(args[0]);
	    else
		System.out.println("Ce type de fichier n'est pas pris en charge pour le moment.");
	}
    }

    
    public static void edgesToDot(String filename) {
	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

	    String line;
	    String nomSansExtension = nomSansExtension(filename);
	    String fichierOutput = nomSansExtension + ".dot";
	    try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichierOutput))) {
		bw.write("digraph " + nomSansExtension + " {");
		bw.newLine();
		String idSommet = "0";
		String idVoisin = "0";
		int cpt = 0; //compteur distinguant si on lit la colonne du sommet courant (0) ou de son voisin (1)
		while( (line = br.readLine()) != null) {
		    String[] splitLine = line.split(" |\t");
		    for(String s : splitLine)
			if(!s.equals(""))
			    if(cpt == 0) {
				idSommet = s;
				cpt++;
			    }
			    else {
				idVoisin = s;
				cpt = 0;
				break;
			    }
		    bw.write("\t" + idSommet + " -> " + idVoisin +";");
		    bw.newLine();
		    bw.flush();
		}//fin while
		bw.write("}");
		bw.newLine();
		bw.flush();
	    } catch(IOException e) { System.out.println("Erreur lors de l'écriture :\n" + e); }
	} catch(FileNotFoundException e) { System.out.println("Fichier non trouvé :\n" + e); }

    }//fin edgesToDot



    public static void datToDot(String filename) {
	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

	    String line;
	    String nomSansExtension = nomSansExtension(filename);
	    String fichierOutput = nomSansExtension + ".dot";
	    try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichierOutput))) {
		bw.write("digraph " + nomSansExtension + " {");
		bw.newLine();
		int idSommet = 0;
		while( (line = br.readLine()) != null) {
		    int idVoisin = 0;
		    String[] splitLine = line.split(" ");
		    for(String str : splitLine) {
			if(str.equals("1")) {
			    bw.write("\t" + idSommet + " -> " + idVoisin +";");
			    bw.newLine();
			    bw.flush();
			}
			idVoisin++;
		    }
		    idSommet++;
		}//fin while
		bw.write("}");
		bw.newLine();
		bw.flush();
	    } catch(IOException e) { System.out.println("Erreur lors de l'écriture :\n" + e); }
	} catch(FileNotFoundException e) { System.out.println("Fichier non trouvé :\n" + e); }
    }//fin datToDot


        
    public static String nomSansExtension(String file) {
	String[] path = file.split("/");
	String[] name = path[path.length -1].split("\\.");
	String fichierOutput = "";
	for(int i=0 ; i<name.length -1 ; i++)
	    fichierOutput += name[i] + ".";

	return fichierOutput.substring(0, fichierOutput.length() -1);
    }

}
