public class CoeurDense {

    public static void main(String[] args) {
	if(args.length != 1) { //(graphe au format .dot)
	    System.out.println("Erreur sur le nombre d'argument");
	    System.exit(0);
	}
	else {
	    /*** PARTIE TRAITEMENT DES ARGUMENTS ***/
	    GrapheDotReader gdr = new GrapheDotReader(args[0]);

	    int cptKCore = 0;
	    int indiceK = -1;
	    float densiteMax = 0;

	    while(gdr.graphe.size() != 0 && gdr.graphe.getNombreDArcs() != 0) {
		float densiteCalculee = gdr.graphe.calculDensite();
		if(densiteCalculee > densiteMax) {
		    densiteMax = densiteCalculee;
		    indiceK++;
		}
		gdr.graphe.extractionKCore(cptKCore++);
	    } //fin while

	    System.out.println(indiceK + " " + densiteMax);
	    
	} //fin else args.length
    } //fin main

    
    
}
