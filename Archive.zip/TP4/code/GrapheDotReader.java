import java.util.ArrayList;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.IOException;

public class GrapheDotReader {

    //public ArrayList<Sommet> graphe;
    public Graphe graphe;
    
    public GrapheDotReader(String filename) {
	graphe = load_dot_file(filename);
    }

    
    public static Graphe load_dot_file(String filename) {
	Graphe grapheReturn = new Graphe();

	try {
	    FileReader fr = new FileReader(filename);
	    BufferedReader br = new BufferedReader(fr);

	    String line = br.readLine(); //la 1ere ligne correspond au nom du graphe qui ne nous est pas pertinent

	    Sommet sommetNouveauOuExistant, voisinNouveauOuExistant;
	    	    
	    while( (line = br.readLine()) != null) {
		int idSommet = -1;
		int idVoisin = -1;
	    
		String[] tabLine = line.trim().split(" |->|;");

		/*** ON PARSE NOTRE LIGNE POUR RECUPERER LES IDs DU SOMMET ET DU SOMMET VOISIN DE LA LIGNE LUE  ***/
		boolean tour = false;
		for(String current : tabLine) {
		    try {
			int parsedInt = Integer.parseInt(current);
			if(tour == false) {
			    idSommet = parsedInt;
			    tour = true;
			}
			else {
			    idVoisin = parsedInt;
			    tour = false;
			}
		    } catch(NumberFormatException e) {  }
		}
		if(idSommet != -1) {
		    if( (sommetNouveauOuExistant = contains(grapheReturn, idSommet)) == null) {
			sommetNouveauOuExistant = new Sommet(idSommet, new ArrayList<Sommet>());
			grapheReturn.add(sommetNouveauOuExistant);
		    }
		    if(idVoisin != -1) {
			if( (voisinNouveauOuExistant = contains(grapheReturn, idVoisin)) == null) {
			    voisinNouveauOuExistant = new Sommet(idVoisin, new ArrayList<Sommet>());
			    grapheReturn.add(voisinNouveauOuExistant);
			}
			sommetNouveauOuExistant.addVoisin(voisinNouveauOuExistant);
		    }
		}
	    }//fin while

	    br.close();
	    fr.close();
	} catch(IOException e) {
	    System.out.println(e);
	}
	return grapheReturn;
    }


    public static Sommet contains(ArrayList<Sommet> liste, int id) {
	for(Sommet s : liste)
	    if(s.id == id)
		return s;
	return null;
    }
}
