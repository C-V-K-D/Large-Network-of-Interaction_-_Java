import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashSet;

public class Tarjan {

    private ArrayList<Sommet> graphe;
    private LinkedList<Sommet> pile = new LinkedList<>();
    private int I = 0;

    private ArrayList<Sommet> sommetsNonInitialises = new ArrayList<Sommet>();
    private ArrayList<Sommet> sommetsDepiles = new ArrayList<Sommet>();
    public ArrayList<CFC> listeCFC = new ArrayList<>();
    
    
    public Tarjan(ArrayList<Sommet> liste) {
	graphe = liste;
	for(Sommet s : graphe)
	    sommetsNonInitialises.add(s);
	algo();
    }

    public void algo() {
	//Si le graphe de départ est vide, alors il n'y a pas de CFC, donc on renvoie une liste vide
	if( sommetsNonInitialises.isEmpty() )
	    listeCFC.add(new CFC());
	else
	    while( !sommetsNonInitialises.isEmpty() ) {
		Sommet current = sommetsNonInitialises.get(0);
		auxiliaire_rec(current);
	    }
    }


    private void auxiliaire_rec(Sommet current) {
	sommetsNonInitialises.remove(current);
	current.index = I;
	current.decouverte = I++;
	pile.addFirst(current);
	for(Sommet v : current.voisinsSortants) {
	    if(v == current) //Cas où un sommet boucle sur lui même
		continue;
	    if( !pile.contains(v) && !sommetsDepiles.contains(v) ) //On répercute l'algo si le voisin n'est pas dans la pile et s'il n'a pas été dépilé
		auxiliaire_rec(v);
	    if( pile.contains(v) ) //Permet d'éviter d'écraser la valeur current.index récupérée, si jamais on fait un min avec la valeur v.index d'un voisin
		//current.index = (current.decouverte < v.index)? current.decouverte : v.index;
		current.index = (current.index < v.index)? current.index : v.index;
	}

	if(current.index == current.decouverte) {
	    CFC cfc = new CFC();
	    Sommet s;
	    do {
		s = pile.removeFirst();
		cfc.add(s);
		sommetsDepiles.add(s);
	    } while(s != current);
	    listeCFC.add(cfc);
	}
    } //fin private void auxiliaire_rec(Sommet current)
  

} //fin class
