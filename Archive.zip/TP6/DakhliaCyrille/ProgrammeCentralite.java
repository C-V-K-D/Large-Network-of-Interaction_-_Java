public class ProgrammeCentralite {
    public static void main(String[] args) {
	if(args.length != 0 && args.length != 2)
	    perror("Erreur sur le nombre d'argument");
	else if(args.length == 0)
	    printHelp();
	else { //args.length == 2
	    GrapheDotReader gdr = new GrapheDotReader(args[1]);
	    if(args[0].equals("-p"))
		gdr.graphe.CentraliteProximite();
	    else if(args[0].equals("-i"))
		gdr.graphe.CentraliteIntermediarite();
	    else
		perror("Mauvais argument : option de calcul de centralité");
	    for(Sommet s : gdr.graphe.values())
		System.out.println(s.id + "\t" + s.centralite);
	}
    }

    private static void perror(String msg) {
	System.out.println(msg);
	System.exit(0);
    }

    private static void printHelp() {
	System.out.println("Bienvenu dans l'assistance au calcul de centralité des sommets de votre graphe !\n" +
			   "\tOptions :\n" +
			   "\t\t1er argument :\n" +
			   "\t\t\t\"-p\" : calcul de la centralité de proximité de chaque sommet\n" +
			   "\t\t\t\"-i\" : calcul de la centralité d'intermédiarité de chaque sommet\n" +
			   "\t\t2ème argument :\n" +
			   "\t\t\tgraphe.dot : nom du fichier contenant le graphe au format .dot\n\n" +
			   "Exemple : \"java ProgrammeCentralite -p graphe.dot\"");
    }

}
