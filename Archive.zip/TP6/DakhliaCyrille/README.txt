UTILISATION DU PROGRAMME MIS A DISPOSITION :


1. COMPILATION :
   => "javac *.java"


2. EXECUTION :

- ProgrammeCentralite :
     Options :
        1er argument :
	   "-p" : calcul de la centralité de proximité de chaque sommet
	   "-i" : calcul de la centralité d'intermédiarité de chaque sommet
	2ème argument :
	   graphe.dot : nom du fichier contenant le graphe au format .dot

    Exemple :
    	    "java ProgrammeCentralite -p graphe.dot"
	    "java ProgrammeCentralite -i graphe.dot"
