UTILISATION DES PROGRAMMES MIS A DISPOSITION :


1. COMPILATION :
   => "javac *.java"


2. EXECUTION :

- CalculCFC.java :
   	"java CalculCFC $1"
	      avec $1 correspondant au nom du fichier d'extension ".dot"
