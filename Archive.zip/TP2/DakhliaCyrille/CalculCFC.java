import java.util.ArrayList;

public class CalculCFC {

    public static void main(String[] args) {
	if(args.length != 1) {
	    System.out.println("Erreur sur le nombre d'argument");
	    System.exit(0);
	}
	else {
	    GrapheDotReader gdr = new GrapheDotReader(args[0]);
	    Tarjan tarjan = new Tarjan(gdr.graphe);

	    System.out.println("Nombre de composantes fortement connexes : " + tarjan.listeCFC.size());

	    for(CFC cfc : tarjan.listeCFC) {
		System.out.print("Composante Fortement Connexe :");
		for(Sommet s : cfc.listeSommets)
		    System.out.print(" " + s.id);
		System.out.println();
	    }
	}
    }
    
}
