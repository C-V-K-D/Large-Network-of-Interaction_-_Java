import java.util.ArrayList;

public class CFC {

	public ArrayList<Sommet> listeSommets;

	public CFC() {
		listeSommets = new ArrayList<>();
	}

    public void add(Sommet s) {
	listeSommets.add(s);
    }
}
