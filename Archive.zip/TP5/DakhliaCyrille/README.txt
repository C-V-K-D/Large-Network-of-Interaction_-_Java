UTILISATION DU PROGRAMME MIS A DISPOSITION :


1. COMPILATION :
   => "javac *.java"


2. EXECUTION :

- ProgrammeGenerationGrapheAleatoire :

   	"java ProgrammeGenerationGrapheAleatoire"
	      --> Affiche les options disponibles concernant les arguments à fournir au programme


	"java ProgrammeGenerationGrapheAleatoire $1 $2 $3 $opt1 $opt2"
	      avec $1 correspondant au choix de la méthode de génération :
	      	   > "er" pour Erdos-Renyi
		   > "pl" pour Power-Law
		   ===> $1 € {"er" , "pl"}
	      avec $2 correspondant :
	      	   > au nombre de sommets pour Erdos-Renyi
		   > au nombre de sommets de degré 1 pour Power-Law
		   ===> $2 € [0, 1, 2, ...]
	      avec $3 correspondant à :
	      	   > la probabilité d'apparition d'une arête pour Erdos-Renyi
		   > la puissance gamma pour Power-Law
		   ===> $3 est un nombre à virgule
		   ===> $3 € [0, 1] pour Erdos-Renyi
		   ===> $3 > 1 pour Power-Law

	     avec $opt1 et $opt2 deux arguments optionnels pouvant être (ordre indifférent, doivent être après les 3 premiers paramètres) :
	     	  > "-s nom_de_fichier.dot" : donne le nom de fichier au format .dot dans lequel on veut enregistre le graphe généré
		    	* Si l'argument n'est pas donné, alors le programme génère un nom de fichier à partir du graphe créé
			* Exemple : "ProgrammeGenerationGrapheAleatoire er 100 0.5" crée un fichier nommé "er_100_0v5.dot"
		  > "-mode_affichage" : où mode_affichage (précédé d'un tiret) correspond à un programme d'affichage du package graphviz (dot, neato, circo, twopi, fdp)
		    	* Si l'argument n'est pas donné, alors le programme utilise "neato" par défaut




Information :
	    - L'affichage du graphe se fait via l'application "eog".
