import java.util.ArrayList;
import java.util.LinkedList;
import java.util.HashMap;
import java.util.Collections;
import java.util.Comparator;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Graphe extends ArrayList<Sommet> {
    public static final String NOM_FICHIER = "graphe";
    public static final String NOM_FICHIER_DOT = "graphe.dot";
    
    public Graphe() {
	super();
    }

    public int getNombreDArcs() {
	int sum = 0;
	for(Sommet s : this)
	    sum += s.degSortant;
	return sum;
    }
    public int getNombreDArcsNonOrientes() { return this.getNombreDArcs() / 2; }
    
    public String toString() {
	String str = "";
	for(Sommet s : this)
	    str += s.toString();
	return str;
    }
    public Sommet containsId(int id) {
	for(Sommet s : this)
	    if(s.id == id)
		return s;
	return null;
    }
    
    /*Deux méthodes pour tester la stabilité du graphe :
     *   - un booléen testant si une modification du graphe a été effectué
     *   - tester la taille du graphe (moins performant selon la manière de la calculer)
     */
    public Graphe extractionKCore(int k) {
	boolean grapheInstable = true;
	ArrayList<Sommet> sommetsASupprimer = new ArrayList<Sommet>();

	while( grapheInstable ) {
	    grapheInstable = false;
	    for(Sommet s : this) {
		if(s.degSortant < k) {
		    sommetsASupprimer.add(s);
		    for(Sommet ve : s.voisinsEntrants)
			ve.removeVoisinSortant(s);
		    for(Sommet vs : s.voisinsSortants)
			vs.removeVoisinEntrant(s);
		}
	    }
	    for(Sommet s : sommetsASupprimer) {
		this.remove(s);
		grapheInstable = true;
	    }
	    sommetsASupprimer.clear();
	}	
	return this;
    }


    public Graphe renumerotation() {
	Collections.sort(this, new Comparator<Sommet>() {
		public int compare(Sommet s1, Sommet s2) {
		    return ((Integer)(s1.id)).compareTo((Integer)(s2.id));
		}
	    });
	int cpt = 0;
	for(Sommet s : this)
	    s.id = cpt++;
	return this;
    }


    public float calculDensite() {
	return (float)this.getNombreDArcs() / this.size();
    }


    public int coeurDense() {
	int cptKCore = -1;
	int indiceK = 0;
	float densiteMax = 0;

	while(this.size() != 0 && this.getNombreDArcs() != 0) {
	    this.extractionKCore(++cptKCore);
	    float densiteCalculee = this.calculDensite();
	
	    if(densiteCalculee > densiteMax) {
		densiteMax = densiteCalculee;
		indiceK = cptKCore; //indiceK++;
	    }
	} //fin while
	return indiceK;
    }


    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    public float calculDiametre() {
	int random = (int)(Math.random() * this.size());
	Sommet randomEdge = this.get(random);

	System.out.println("La fonction de calcul du diamètre n'est malheureusement pas terminée");
	return 0;
    }

    public LinkedList<Sommet> parcoursMax_parcoursLargeur_rec(Sommet initial, int numeroMarquage) {
	LinkedList<Sommet> fifo = new LinkedList<>();
	
	fifo.add(initial);

	while( !fifo.isEmpty() ) {
	    Sommet current = fifo.removeFirst();
	    switch(numeroMarquage) {
	    case 1:
		current.marquage_4_sweep_1 = Sommet.VISITE;
		break;
	    case 2:
		current.marquage_4_sweep_2 = Sommet.VISITE;
		break;
	    case 3:
		current.marquage_4_sweep_3 = Sommet.VISITE;
		break;
	    case 4:
		current.marquage_4_sweep_4 = Sommet.VISITE;
		break;
	    default:
		System.out.println("Graphe.java > parcoursMax_parcoursLargeur_rec > Mauvais numeroMarquage");
		break;
	    }
	    for(Sommet voisin : current.voisinsSortants) {
		switch(numeroMarquage) {
		case 1:
		    if(voisin.marquage_4_sweep_1 == Sommet.NON_VISITE) {
			voisin.marquage_4_sweep_1 = Sommet.SEMI_VISITE;
			fifo.add(voisin);
		    }
		    break;
		case 2:
		    if(voisin.marquage_4_sweep_2 == Sommet.NON_VISITE) {
			voisin.marquage_4_sweep_2 = Sommet.SEMI_VISITE;
			fifo.add(voisin);
		    }
		    break;
		case 3:
		    if(voisin.marquage_4_sweep_3 == Sommet.NON_VISITE) {
			voisin.marquage_4_sweep_3 = Sommet.SEMI_VISITE;
			fifo.add(voisin);
		    }
		    break;
		case 4:
		    if(voisin.marquage_4_sweep_4 == Sommet.NON_VISITE) {
			voisin.marquage_4_sweep_4 = Sommet.SEMI_VISITE;
			fifo.add(voisin);
		    }
		    break;
		default:
		    System.out.println("Graphe.java > parcoursMax_parcoursLargeur_rec > Mauvais numeroMarquage");
		    break;
		}//fin switch
		
	    }//fin for parcours current.voisinsSortants
	}//fin while !fifo.isEmpty()
	return null;
    }
    /*
    public static int nb_sommets_accessibles_parcours_profondeur_rec(Sommet initial) {
	initial.marquage = Sommet.VISITE;
	
	if(initial.aucun_voisin_visitable()) {
	    return 1;
	}
	else {
	    int[] somme_sommets = new int[initial.voisins.size()]; //tableau initialise a 0 en java

	    for(int i=0 ; i<initial.voisins.size() ; i++) {
		Sommet s = initial.voisins.get(i);
		if(s.marquage == Sommet.NON_VISITE) {
		    s.marquage = Sommet.SEMI_VISITE;
		    somme_sommets[i] = nb_sommets_accessibles_parcours_profondeur_rec(s);
		}
	    }
	    int somme = 0;
	    for(int i=0 ; i<somme_sommets.length ; i++)
		somme += somme_sommets[i];
	    return 1 + somme;
	}
    }    
    */
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/
    /*** PARTIE CALCULE DU DIAMETRE EN COURS DE CONSTRUCTION ***/


    
    /*** ECRITURE DU GRAPHE DANS UN FICHIER .DOT ***/
    //Ecrit ce graphe dans le fichier "graphe.dot" et renvoie ce nom
    public String ecritureFichierDot(boolean oriented) {
	return ecritureFichierDot("graphe.dot", oriented);
    }
    //Ecrit ce graphe dans le fichier de nom fichierOutput et renvoie ce nom
    public String ecritureFichierDot(String fichierOutput, boolean oriented) {
	HashMap<Integer, ArrayList<Integer>> liaisons = new HashMap<>();
	
	String typeGraph = (oriented) ? "digraph" : "graph";
	System.out.println("ECRITURE FICHIER : " + fichierOutput);
		
	try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichierOutput))) {
	    //bw.write(typeGraph + " " + fichierOutput.split("\\.")[0] + " {");
		
	    String nameDigraph = fichierOutput.substring(0, fichierOutput.length() - ".dot".length());
	    bw.write(typeGraph + " " + nameDigraph + " {");
	    bw.newLine();
	    for(Sommet s : this) {
		if(s.voisinsSortants.size() == 0) {
		    bw.write(s.id + ";");
		    bw.newLine();
		}
		else
		    for(Sommet vs : s.voisinsSortants) {
			if(oriented) {
			    bw.write(s.id + " -> " + vs.id + ";");
			    bw.newLine();
			}
			else {
			    if(liaisons.get(vs.id) != null) {
				if( !liaisons.get(vs.id).contains(s.id) ) {
				    liaisons.get(vs.id).add(s.id);
				    bw.write(s.id + " -- " + vs.id + ";");
				    bw.newLine();
				}
			    }
			    else {
				if(liaisons.get(s.id) == null) {
				    ArrayList<Integer> liaison_voisins = new ArrayList<>();
				    liaison_voisins.add(vs.id);
				    liaisons.put(s.id, liaison_voisins);
				}
				else
				    liaisons.get(s.id).add(vs.id);
				bw.write(s.id + " -- " + vs.id + ";");
				bw.newLine();
			    }
			}
		    }//fin for
		bw.flush();
	    }
	    bw.write("}");
	    bw.newLine();
	    bw.flush();
	    //bw.close(); //Déjà géré par le try-with-resources => AutoCloseable
	} catch(IOException e) { System.out.println("[Graphe.java]: Erreur lors de l'écriture :\n" + e); }
	return fichierOutput;
    }

}
