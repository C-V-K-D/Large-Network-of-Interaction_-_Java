import java.util.ArrayList;
import java.util.Arrays;
import java.io.IOException;

public class ProgrammeGenerationGrapheAleatoire {
    
    private static final String APP_AFFICHAGE = "eog";
    private static final ArrayList<String> LISTE_MODE_AFFICHAGE = new ArrayList<>(Arrays.asList("dot", "neato", "twopi", "circo", "fdp"));
    private static final String MODE_AFFICHAGE_DEFAUT = "neato";

    
    public static void main(String[] args) {
	if(args.length != 0 && args.length != 3 && args.length != 4 && args.length != 5 && args.length != 6)
	    perror("Erreur sur le nombre d'argument");
	else if(args.length == 0)
	    printHelp();
	else {
	    int arg1 = 0;
	    double arg2 = 0;
	    try {
		arg1 = Integer.parseInt(args[1]);
		arg2 = Double.parseDouble(args[2]);
	    } catch(NumberFormatException nfe) {
		System.out.println("Erreur : argument(s) incorrect(s) -> argument(s) 1 et/ou 2 :\n" + nfe);
	    }
	    if( !args[0].equals("er") && !args[0].equals("pl"))
		perror("Erreur : argument incorrect -> méthode de génération de graphe.");

	    RandomUndirectedGraphGenerator rugg = new RandomUndirectedGraphGenerator();
	    Graphe graphe = (args[0].equals("er")) ? rugg.ErdosRenyi(arg1, arg2) : rugg.PowerLaw(arg1, arg2);

	    String filename = "";
	    String modeAffichage = MODE_AFFICHAGE_DEFAUT;
	    if(args.length == 5)
		filename = getFilename(args[3], args[4]);
	    else if(args.length == 6) {
		filename = (args[3].equals("-s")) ? getFilename(args[3], args[4]) : getFilename(args[4], args[5]);
		modeAffichage = (args[3].equals("-s")) ? getModeAffichage(args[5]) : getModeAffichage(args[3]);
	    }
	    else { //args.length == 3 || 4
		if(args.length == 4)
		    modeAffichage = getModeAffichage(args[3]);
		filename = getDefaultFilename(args[0], args[1], args[2]);
	    }
	

	    /*** PARTIE ECRITURE DANS UN FICHIER ***/
	    graphe.ecritureFichierDot(filename, false);


	    /*** PARTIE EXECUTION DE LA COMMANDE D'AFFICHAGE DU GRAPHE ***/
	    Runtime runtime = Runtime.getRuntime();
	    try {
		runtime.exec(new String[] {modeAffichage, "-Tpng", "-O", filename}).waitFor();
		runtime.exec(new String[] {APP_AFFICHAGE, filename + ".png"});
	    } catch(IOException ioe) { System.out.println("RUGG : runtime.exec :\n" + ioe);
	    } catch(InterruptedException ie) { System.out.println("RUGG : runtime.exec :\n" + ie); }
		 

	    /*** DON DU NOMBRE DE SOMMETS ET D'ARÊTES ***/
	    System.out.println("Nombre de sommets : " + graphe.size() + "\n" +
			       "Nombre d'arêtes   : " + graphe.getNombreDArcsNonOrientes());


	    /*** DON DU NOMBRE DE COMPOSANTES CONNEXES ET DE LA TAILLE DE LA PLUS GROSSE ***/
	    Tarjan tarjan = new Tarjan(graphe);
	    System.out.println("Nombre de composantes connexes : " + tarjan.listeCFC.size() + "\n" +
			       "Taille de la plus grosse CC    : " + tarjan.tailleCFCMax);


	    /*** CALCUL DU DIAMETRE DU GRAPHE ***/
	    float diametre = 0;
	    

	    /*** DON DE LA VALEUR DE K PRODUISANT LE K-COEUR LE PLUS DENSE ***/
	    System.out.println("Le k-coeur le plus dense est obtenu pour k valant : " + graphe.coeurDense());


	    /*** DON DU DIAMETRE DU GRAPHE ***/
	    System.out.println("Diamètre du graphe : " + diametre + " -> cette partie n'a malheureusement pas été terminé à temps : problème d'implémentation du BFS pour appliquer la méthode 4-sweep");
	    
	}//fin else args.length
    }//fin main






    /*************************************************
     ********* FONCTION DE GESTION DU PROGRAMME ******
     *************************************************/
    private static void perror(String msg) {
	System.out.println(msg);
	System.exit(0);
    }
    private static String getModeAffichage(String arg) {
	if( !LISTE_MODE_AFFICHAGE.contains(arg.substring(1)) )
	    perror("Erreur : argument incorrect -> mode d'affichage.");
	return arg.substring(1);	
    }
    private static String getFilename(String arg1, String arg2) {
	if( !arg1.equals("-s") || !arg2.substring(arg2.length() - 4).equals(".dot"))
	    perror("Erreur : argument incorrect -> nom de fichier de sauvegarde du graphe au format .dot.");
	return arg2;
    }
    private static String getDefaultFilename(String arg1, String arg2, String arg3) {
	String[] args3 = arg3.split("\\.");
	String ret = arg1 + "_" + arg2 + "_";
	ret = (args3.length == 2) ? ret + args3[0] + "v" + args3[1] + ".dot" : ret + args3[0] + ".dot";
	return ret;
    }
    private static void printHelp() {
	System.out.println("Bienvenu dans l'assistance à la génération de graphes pseudo-aléatoires suivant la méthode d'Erdos-Renyi ou du Power-Law !\n" +
			   "  Veuillez trouver ci-après les détails d'utilisation de notre programme !\n" +
			   "    Bonne génération !\n\n" +
			   " -----> Liste des arguments <-----\n" +
			   "  * Sans argument : c'est ce que vous venez de faire pour afficher ce message d'assistance à l'utilisation de notre programme !\n" +
			   "  * multi-arguments :\n" +
			   "      java ProgrammeGenerationGrapheAleatoire $1 $2 $3 $opt1 $opt2\n" +
			   "         avec $1 correspondant au choix de la méthode de génération :\n" +
			   "            > \"er\" pour Erdos-Renyi\n" +
			   "            > \"pl\" pour Power-Law\n" +
			   "            ===> $1 € {\"er\" , \"pl\"}\n" +
			   "         avec $2 correspondant :\n" +
			   "            > au nombre de sommets pour Erdos-Renyi\n" +
			   "            > au nombre de sommets de degré 1 pour Power-Law\n" +
			   "            ===> $2 € [0, 1, 2, ...]\n" +
			   "         avec $3 correspondant à :\n" +
			   "            > la probabilité d'apparition d'une arête pour Erdos-Renyi\n" +
			   "            > la puissance gamma pour Power-Law\n" +
			   "            ===> $3 est un nombre à virgule\n" +
			   "            ===> $3 € [0, 1] pour Erdos-Renyi\n" +
			   "            ===> $3 > 1 pour Power-Law\n" +
			   "\n" +
			   "        avec $opt1 et $opt2 deux arguments optionnels pouvant être (ordre indifférent, doivent être après les 3 premiers paramètres) :\n" +
			   "            > \"-s nom_de_fichier.dot\" : donne le nom de fichier au format .dot dans lequel on veut enregistre le graphe généré\n" +
			   "               * Si l'argument n'est pas donné, alors le programme génère un nom de fichier à partir du graphe créé\n" +
			   "               * Exemple : \"ProgrammeGenerationGrapheAleatoire er 100 0.5\" crée un fichier nommé \"er_100_0v5.dot\"\n" +
			   "            > \"-mode_affichage\" : où mode_affichage (précédé d'un tiret) correspond à un programme d'affichage du package graphviz (dot, neato, circo, twopi, fdp)\n" +
			   "               * Si l'argument n'est pas donné, alors le programme utilise \"neato\" par défaut\n" +
			   "\n" +
			   "Information :\n" +
			   "   -> L'affichage du graphe se fait via l'application \"eog\".");
    }
    private static void printHelp_old() {
	System.out.println("Bienvenu dans l'assistance à la génération de graphes pseudo-aléatoires suivant la méthode d'Erdos-Renyi ou du Power-Law !\n" +
			   "  Veuillez trouver ci-après les détails d'utilisation de notre programme !\n" +
			   "    Bonne génération !\n\n" +
			   " -----> Liste des arguments <-----\n" +
			   "  * Sans argument : c'est ce que vous venez de faire pour afficher ce message d'assistance à l'utilisation de notre programme !\n" +
			   "  * multi-arguments :\n" +
			   "     > param 1 : chaîne de caractères désignant le mode de génération du graphe aléatoire (\"er\" pour Erdos-Renyi, \"pl\" pour Power-Law)\n" +
			   "     > param 2 : entier désignant le nombre de sommets pour \"er\", ou le nombre de sommets de degré 1 pour \"pl\"\n" +
			   "     > param 3 : double désignant la probabilité d'apparition d'une arête pour \"er\" (compris entre 0 et 1 inclus), ou la puissance gamma pour \"pl\" (strictement supérieure à 1)\n" +
			   "     > param optionnels (ordre indifférent après les 3 premiers paramètres) :\n" +
			   "        * \"-s nom_de_fichier.dot\" : donne le nom de fichier dans lequel on veut enregistrer le graphe généré au format .dot\n" +
			   "        * \"-mode_affichage\" : où \"mode_affichage\" (précédé d'un tiret) correspond à un programme d'affichage du package graphviz (dot, neato, circo, twopi, fdp) (neato par défaut)\n\n" +
			   "L'affichage du graphe se fait via l'application \"eog\".");
    }

}
