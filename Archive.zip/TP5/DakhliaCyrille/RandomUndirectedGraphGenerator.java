import java.util.ArrayList;

public class RandomUndirectedGraphGenerator {

    public RandomUndirectedGraphGenerator() {    }

    public Graphe ErdosRenyi(int n, double p) {
	Graphe ER = new Graphe();
	for(int i=0 ; i<n ; i++)
	    ER.add(new Sommet(i));

	if(p == 0)
	    return ER;
	else
	    for(int i=0 ; i<n ; i++)
		for(int j=i+1 ; j<n ; j++)
		    if(p == 1 || Math.random() < p)
			ER.get(i).addVoisinNonOriente(ER.get(j));
	return ER;
    }


    private static void afficherTableau(ArrayList<Integer> tab) {
	for(int i : tab)
	    System.out.print(i + " ");
	System.out.println();
    }
    private static void afficherTableau(Integer[] tab) {
	for(Integer i : tab)
	    System.out.print(i + "|");
	System.out.println();
    }
    private static Integer[] permutationAleatoire(Integer[] tab) {
	int random, tmp;
	for(int i=0 ; i<tab.length ; i++) {
	    random = (int)(Math.random() * tab.length);
	    if(random != i) {
		tmp = tab[i];
		tab[i] = tab[random];
		tab[random] = tmp;
	    }
	}
	return tab;
    }
    private int PowerLaw_function_Nbx(int x, int n1, double gamma) {
	return (int)(0.5 + (n1*Math.pow(x, -gamma)));
    }
    public Integer[] PowerLaw_distributionDegres(int n1, double gamma) {
	int Nbx; int x = 1; int n = 0;
	while( (Nbx = PowerLaw_function_Nbx(x++, n1, gamma)) != 0)
	    n += Nbx; //taille du tableau = somme des Nbx

	Integer[] tab = new Integer[n]; //on crée notre tableau
	x = 1; int cpt = 0;
	while(cpt < n) {
	    Nbx = PowerLaw_function_Nbx(x, n1, gamma);
	    for(int i=0 ; i<Nbx ; i++) {
		tab[cpt++] = x; //on le remplit
	    }
	    x++;
	}
	//	System.out.print("TAB   --> "); afficherTableau(tab);
	return permutationAleatoire(tab);	
    }
    public Graphe PowerLaw_MolloyReed(Integer[] tab) {
	//Question III/ b) 1.
	//	System.out.print("TAB_R --> "); afficherTableau(tab);
	ArrayList<Integer> L = new ArrayList<>();
	int cpt = 0;
	for(int i : tab) {
	    for(int k=0 ; k<i ; k++)
		L.add(cpt);
	    cpt++;
	}

	//Question III/ b) 2.
	Integer[] mrTab = new Integer[L.size()];
	mrTab = L.toArray(mrTab);


	//	System.out.println("L.size() = " + L.size());
	//	System.out.println("mrTab.length = " + mrTab.length);
	//	System.out.print("TABLO --> "); afficherTableau(mrTab);
	//	System.out.print("LISTE --> "); afficherTableau(L);

	
	Integer[] randomTab = permutationAleatoire(mrTab);


	//	System.out.print("RANDO --> "); afficherTableau(randomTab);

	
	//Question III/ b) 3.
	Graphe graphe = new Graphe();
	//	System.out.println("CREATION DU GRAPHE : ");
	int[] sommetsAjoutes = new int[randomTab.length];
	for(Integer i : randomTab) {
	    //	    System.out.println("***** i = " + i);
	    if(sommetsAjoutes[i.intValue()] == 0) {
		graphe.add(new Sommet(i.intValue()));
		sommetsAjoutes[i.intValue()] = 1;
	    }
	}
	
	
	//	System.out.println("graphe.size() = " + graphe.size());
	//	System.out.print("Graphe Sommets : ");
	//	for(Sommet s : graphe)
	//	    System.out.print(s.id + " ");
	//	System.out.println();


	for(int i=0 ; i<randomTab.length -1 ; i+=2)
	    if(randomTab[i] != randomTab[i+1]) {
		Sommet s1 = graphe.containsId(randomTab[i]);
		Sommet s2 = graphe.containsId(randomTab[i+1]);
		if( ! s1.voisinsSortants.contains(s2)) //le graphe est rempli dans le meme ordre que notre tableau d'Integer puisque c'est de lui qu'on a peuple notre graphe
		    s1.addVoisinNonOriente(s2);
	    }
	return graphe;
    }
    public Graphe PowerLaw(int n1, double gamma) {
	return PowerLaw_MolloyReed(PowerLaw_distributionDegres(n1, gamma));
    }


}
