import java.util.ArrayList;

public class Sommet {

    public int id;
    public ArrayList<Sommet> voisinsSortants;
    public ArrayList<Sommet> voisinsEntrants;

    public int index = -1;
    public int decouverte = -1;

    public int degSortant = 0;
    public int degEntrant = 0;

    public char marquage;
    public char marquage_4_sweep_1;
    public char marquage_4_sweep_2;
    public char marquage_4_sweep_3;
    public char marquage_4_sweep_4;
    public static final char VISITE = 'b';
    public static final char NON_VISITE = 'w';
    public static final char SEMI_VISITE = 'g';

    public Sommet(int id) {
	this.voisinsSortants = new ArrayList<>();
	this.voisinsEntrants = new ArrayList<>();
	this.id = id;
	this.marquage = NON_VISITE;
	this.marquage_4_sweep_1 = NON_VISITE;
	this.marquage_4_sweep_2 = NON_VISITE;
	this.marquage_4_sweep_3 = NON_VISITE;
	this.marquage_4_sweep_4 = NON_VISITE;
    }
    public Sommet(int id, ArrayList<Sommet> listeVoisinsSortants) {
	this(id);
	for(Sommet s : listeVoisinsSortants)
	    this.addVoisin(s);

    }

    public void addVoisinNonOriente(Sommet s) {
	this.voisinsSortants.add(s);
	this.degSortant++;
	this.degEntrant++;
	s.voisinsSortants.add(this);
	s.degSortant++;
	s.degEntrant++;
    }
    public void addVoisin(Sommet s) {
	this.voisinsSortants.add(s);
	this.degSortant++;
	s.voisinsEntrants.add(this);
	s.degEntrant++;
    }
    public void removeVoisinEntrant(Sommet s) {
	this.voisinsEntrants.remove(s);
	this.degEntrant--;
    }
    public void removeVoisinSortant(Sommet s) {
	this.voisinsSortants.remove(s);
	this.degSortant--;
    }

    public String toString() {
	String str = "Sommet "+id+", deg-="+degEntrant+", deg+="+degSortant + "\n";
	for(Sommet s : voisinsSortants)
	    str += "   "+id+" -> "+s.id;
	return str + "\n";
    }
    public void affiche() {
	System.out.println("Sommet "+id+", deg-="+degEntrant+", deg+="+degSortant);
	for(Sommet s : voisinsSortants)
	    System.out.println("   "+id+" -> "+s.id);
	//System.out.println();
    }

    public boolean aucun_voisin_visitable() {
	for(Sommet s : voisinsSortants)
	    if(s.marquage == NON_VISITE)
		return false;
	return true;
    }

    public boolean est_non_initialise() {
	return index == -1 || decouverte == -1;
    }
}
