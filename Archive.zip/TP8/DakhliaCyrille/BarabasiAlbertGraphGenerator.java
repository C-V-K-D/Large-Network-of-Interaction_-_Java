import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class BarabasiAlbertGraphGenerator {
    private int d, n0, n;
    private boolean oriented;
    private int nbAretes = 0;
    
    public BarabasiAlbertGraphGenerator(int d, int n0, int n, boolean oriented) {
	this.d = d;
	this.n0 = n0;
	this.n = n;
	this.oriented = oriented;
    }

    //Gerer ca avec la classe Graphe en int[] au lieu d'une HashMap
    public Graphe genererGraphe() {
    //public Sommet[] genererGraphe() {
	Graphe graphe = new Graphe(n);
	//Sommet[] graphe = new Sommet[n];
	int cptId = n0;

	//Création des n0 sommets initiaux
	for(int i=0 ; i<n0 ; i++)
	    graphe.graphe[i] = new Sommet(i);
	//Création des arêtes entre ces n0 sommets initiaux
	for(int i=0 ; i<n0-1 ; i++)
	    for(int j=i+1 ; j<n0 ; j++)
		if(oriented) {
		    graphe.graphe[i].addVoisin(graphe.graphe[j]);
		    graphe.graphe[j].addVoisin(graphe.graphe[i]);
		    nbAretes += 2;
		}
		else {
		    graphe.graphe[i].addVoisinNonOriente(graphe.graphe[j]); //Ajoute i->j et i<-j
		    nbAretes += 1;
		}
	
	/******* A ENLEVER ****/
	//	for(Sommet s : graphe)
	//	    System.out.println(s);
	/****** A ENLEVER ****/
	
	if(n0 == n) return graphe;
	else {
	    int nbSommetsACreer = n - n0;
	    Sommet newOne, chosenOne = null;
	    //	    float probaMax;
	    //	    float probaCalculee;
	    int nbConnexionsRestantes, sommeDegresDesEligibles, degTotal;
	    ArrayList<Sommet> eligibles;
	    HashMap<Sommet, Integer> mapProba;
	    while(nbSommetsACreer > 0) {
		eligibles = new ArrayList<>(Arrays.asList(graphe.graphe));
		newOne = new Sommet(cptId); //On crée notre nouveau sommet
		graphe.graphe[cptId++] = newOne; //On l'ajoute d'ores et déjà dans notre graphe
		nbSommetsACreer--;
		nbConnexionsRestantes = d;
		sommeDegresDesEligibles = 2 * nbAretes;
		//		System.out.println("somme = " +sommeDegresDesEligibles);
		//		probaMax = 0;
		while(nbConnexionsRestantes > 0) {
		    mapProba = new HashMap<>();
		    if(eligibles.size() == 0) System.out.println("plu deligibles");
		    for(Sommet s : eligibles) {
			if(s == null) continue;
			degTotal = (oriented)? s.degSortant + s.degEntrant : s.degSortant;
			//			System.out.println("degTotal = " + degTotal);
			//  probaCalculee = degTotal/sommeDegresDesEligibles;
			mapProba.put(s, degTotal);
			//  mapProba.put(s, probaCalculee);
			//			if(probaCalculee > probaMax) {
			//			    probaMax = probaCalculee;
			//			    chosenOne = s;
			//			}
		    } //fin for(Sommet s : eligibles)
		    //A chaque fois qu'on ajoute une connexion on augmente nbAretes et on diminue nbAretesComptabilisees
		    chosenOne = electionProba(mapProba, sommeDegresDesEligibles);
		    //		    System.out.println("\t\tchosenOne.id = " + chosenOne.id);
		    if(oriented) newOne.addVoisin(chosenOne);
		    else newOne.addVoisinNonOriente(chosenOne);
		    nbAretes++;
		    //		    System.out.println("\t\tsommeAVT= " + sommeDegresDesEligibles);
		    sommeDegresDesEligibles -= (oriented)? chosenOne.degSortant + chosenOne.degEntrant -1 : chosenOne.degSortant -1; //-1 car on a ajoute une arete
		    //		    System.out.println("\t\tsommeAPR= " + sommeDegresDesEligibles);
		    eligibles.remove(chosenOne);
		    nbConnexionsRestantes--;
		} //fin while(nbConnexionsRestantes > 0)
	    } //fin while(nbSommetsACreer > 0)

	} //fin else (n0 != n)
	//la probabilité que x se lie avec un autre sommet varie à chaque fois qu'on lie x à un sommet du graphe, car il y aura un sommet éligible en moins	
	return graphe;
    }


    public static Sommet electionProba(HashMap<Sommet, Integer> map, int taille) {
	Sommet[] tab = new Sommet[taille];
	int cpt = 0;
	//	System.out.println("taille = " + taille);
	for(Sommet s : map.keySet()) {
	    //	    System.out.println("map.get(s) = " + map.get(s));
	    for(int i=cpt ; i<(cpt+map.get(s)) ; i++)
		tab[i] = s;
	    cpt += map.get(s);
	}

	int randomIndice = (int)(Math.random() * taille);
	return tab[randomIndice];
    }
    
}
