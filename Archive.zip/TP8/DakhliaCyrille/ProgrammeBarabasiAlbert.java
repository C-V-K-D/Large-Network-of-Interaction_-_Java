import java.util.ArrayList;
import java.util.Arrays;
import java.io.IOException;

public class ProgrammeBarabasiAlbert {
    
    public static void main(String[] args) {
	if(args.length != 0 && args.length != 3 && args.length != 4)
	    perror("Erreur sur le nombre d'argument.");
	else if(args.length == 0)
	    printHelp();
	else {
	    int d = 0;
	    int n0 = 0;
	    int n = 0;
	    boolean oriented = false;
	    try {
		d = Integer.parseInt(args[0]);
		n0 = Integer.parseInt(args[1]);
		n = Integer.parseInt(args[2]);
	    } catch(NumberFormatException nfe) {
		System.out.println("Erreur : argument(s) incorrect(s) -> argument(s) 1 et/ou 2 et/ou 3 :\n" + nfe);
	    }
	    if(d > n0 || n0 > n || d < 0 || n0 <= 1)
		perror("Erreur : d, n0 et n ne peuvent pas être négatifs, et n0 doit être supérieur strictement à 1 (sinon sommeDegresDesEligibles = 0 => division par zéro).");
	    if(args.length == 3) oriented = false;
	    else //args.length == 4
		if( !args[3].equals("-dir") )
		    perror("Erreur : argument incorrect -> indiquez \"-dir\" pour un graphe orienté ou ne mettez pas cet argument pour un graphe non orienté.");
		else oriented = true;
	    
	    BarabasiAlbertGraphGenerator bagg = new BarabasiAlbertGraphGenerator(d, n0, n, oriented);
	    Graphe graphe = bagg.genererGraphe();
	    //Sommet[] graphe = bagg.genererGraphe();
	    /*
	    for(Sommet s : graphe.graphe)
		System.out.println(s);
	    */

	    /*** PARTIE ECRITURE DANS UN FICHIER ***/
	    graphe.ecritureFichierDot(oriented);


	    /**************************************************************************************************/
	    /*
	    String filename = "";
	    String modeAffichage = MODE_AFFICHAGE_DEFAUT;
	    if(args.length == 5)
		filename = getFilename(args[3], args[4]);
	    else if(args.length == 6) {
		filename = (args[3].equals("-s")) ? getFilename(args[3], args[4]) : getFilename(args[4], args[5]);
		modeAffichage = (args[3].equals("-s")) ? getModeAffichage(args[5]) : getModeAffichage(args[3]);
	    }
	    else { //args.length == 3 || 4
		if(args.length == 4)
		    modeAffichage = getModeAffichage(args[3]);
		filename = getDefaultFilename(args[0], args[1], args[2]);
	    }
	    */

	    
	    /*** PARTIE EXECUTION DE LA COMMANDE D'AFFICHAGE DU GRAPHE ***/
	    /*
	    Runtime runtime = Runtime.getRuntime();
	    try {
		runtime.exec(new String[] {modeAffichage, "-Tpng", "-O", filename}).waitFor();
		runtime.exec(new String[] {APP_AFFICHAGE, filename + ".png"});
	    } catch(IOException ioe) { System.out.println("RUGG : runtime.exec :\n" + ioe);
	    } catch(InterruptedException ie) { System.out.println("RUGG : runtime.exec :\n" + ie); }
	    */		 

	    /*** DON DU NOMBRE DE SOMMETS ET D'ARÊTES ***/
	    /*
	    System.out.println("Nombre de sommets : " + graphe.size() + "\n" +
			       "Nombre d'arêtes   : " + graphe.getNombreDArcsNonOrientes());
	    */

	    /*** DON DU NOMBRE DE COMPOSANTES CONNEXES ET DE LA TAILLE DE LA PLUS GROSSE ***/
	    /*
	    Tarjan tarjan = new Tarjan(graphe);
	    System.out.println("Nombre de composantes connexes : " + tarjan.listeCFC.size() + "\n" +
			       "Taille de la plus grosse CC    : " + tarjan.tailleCFCMax);
	    */

	    /*** CALCUL DU DIAMETRE DU GRAPHE ***/
	    //	    float diametre = 0;
	    

	    /*** DON DE LA VALEUR DE K PRODUISANT LE K-COEUR LE PLUS DENSE ***/
	    //	    System.out.println("Le k-coeur le plus dense est obtenu pour k valant : " + graphe.coeurDense());


	    /*** DON DU DIAMETRE DU GRAPHE ***/
	    //	    System.out.println("Diamètre du graphe : " + diametre + " -> cette partie n'a malheureusement pas été terminé à temps : problème d'implémentation du BFS pour appliquer la méthode 4-sweep");
	    
	}//fin else args.length
    }//fin main






    /*************************************************
     ********* FONCTION DE GESTION DU PROGRAMME ******
     *************************************************/
    private static void perror(String msg) {
	System.out.println(msg);
	System.exit(0);
    }
    private static String getFilename(String arg1, String arg2) {
	if( !arg1.equals("-s") || !arg2.substring(arg2.length() - 4).equals(".dot"))
	    perror("Erreur : argument incorrect -> nom de fichier de sauvegarde du graphe au format .dot.");
	return arg2;
    }
    private static String getDefaultFilename(String arg1, String arg2, String arg3) {
	String[] args3 = arg3.split("\\.");
	String ret = arg1 + "_" + arg2 + "_";
	ret = (args3.length == 2) ? ret + args3[0] + "v" + args3[1] + ".dot" : ret + args3[0] + ".dot";
	return ret;
    }
    private static void printHelp() {
	System.out.println("Bienvenu dans l'assistance à la génération de graphes pseudo-aléatoires suivant la méthode de Barabasì-Albert !\n" +
			   "  Veuillez trouver ci-après les détails d'utilisation de notre programme !\n" +
			   "    Bonne génération !\n\n" +
			   " -----> Liste des arguments <-----\n" +
			   "  * Sans argument : c'est ce que vous venez de faire pour afficher ce message d'assistance à l'utilisation de notre programme !\n" +
			   "  * multi-arguments :\n" +
			   "      java ProgrammeBarabasiAlbert $1 $2 $3 $opt1\n" +
			   "         avec $1 correspondant à d : le degré de tous nouveaux sommets ajoutés au graphe généré\n" +
			   "         avec $2 correspondant à n0 : le nombre de sommets initiaux\n" +
			   "         avec $3 correspondant à n : le nombre de sommets final du graphe\n" +
			   "\n" +
			   "        avec $opt1 un argument optionnel devant être :\n" +
			   "            > \"-dir\" : pour obtenir un graphe orienté\n" +
			   "               * Si l'argument n'est pas donné, alors le programme génère un graphe non-orienté par défaut\n" +
			   "\n" +
			   "  * Exemple : \"ProgrammeBarabasiAlbert 10 20 30\"\n" +
			   "              \"ProgrammeBarabasiAlbert 7 54 72 -dir\"");
    }
}
