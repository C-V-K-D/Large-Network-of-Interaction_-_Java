UTILISATION DES PROGRAMMES MIS A DISPOSITION :


1. COMPILATION :
   => "javac *.java"


2. EXECUTION :

- Kcore.java :
   	"java Kcore $0 $1 $2 $3"
	      avec $0 correspondant à l'option "-r" (OPTIONNELLE) permettant de renuméroter les sommets après la k-corisation
	      avec $1 correspondant au nom du fichier d'extension ".dot"
	      avec $2 correspondant à la valeur k de k-corisation
	      avec $3 correspondant au nom de fichier de sortie (doit avoir l'extension ".dot")


- CoeurDense.java :
  	"java CoeurDense $1"
	      avec $1 corresopndant au nom du fichier d'extension ".dot"
