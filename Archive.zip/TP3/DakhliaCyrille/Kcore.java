import java.util.ArrayList;
import java.io.File;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

public class Kcore {

    public static void main(String[] args) {
	if(args.length != 3 && args.length != 4) { //(option -r) + (graphe au format .dot) + (entier k (core)) + (nom de fichier où l'écriture du k-core du graphe)
	    System.out.println("Erreur sur le nombre d'argument");
	    System.exit(0);
	}
	else {
	    /*** PARTIE TRAITEMENT DES ARGUMENTS ***/
	    boolean boolRenumerotation = false;
	    if(args.length == 4)
		if( !args[0].equals("-r") ) {
		    System.out.println("Erreur sur les arguments. Pour 4 arguments, le 1er champ doit être \"-r\"");
		    System.exit(0);
		}
		else //( args[0].equals("-r") )
		    boolRenumerotation = true;
	    else
		boolRenumerotation = false;

	    int n = args.length -1; //position du dernier argument
	    if( !args[n].substring(args[n].length() -4, args[n].length()).equals(".dot") || args[n].length() < 5) {
		System.out.println("Erreur sur les arguments. Le nom du fichier output n'est pas valide.");
		System.exit(0);
	    }

	    
	    GrapheDotReader gdr = (args.length == 3)? new GrapheDotReader(args[0]) : new GrapheDotReader(args[1]);
	    int kCoreIndice = 0;
	    try {
		kCoreIndice = (args.length == 3)? Integer.parseInt(args[1]) : Integer.parseInt(args[2]);
	    } catch(NumberFormatException e) { System.out.println("Erreur sur l'indice de k-core :\n" + e); }
	    String fichierOutput = (args.length == 3)? args[2] : args[3];

	    
	    /*** EXTRACTION DU K-CORE ***/
	    gdr.graphe.extractionKCore(kCoreIndice);
	    
	    
	    /*** AFFICHAGE DES DONNEES PERTINENTES ***/
	    int sum = 0;
	    for(Sommet s : gdr.graphe)
		sum += s.degSortant; //Calcul du nombre d'arêtes m
	    System.out.println("n=" + gdr.graphe.size() + " m=" + sum);


	    /*** TRAITEMENT DE LA RENUMEROTATION ***/
	    if(boolRenumerotation)
		gdr.graphe.renumerotation();

	    
	    /*** ECRITURE DU K-CORE DANS UN FICHIER ***/
	    File file = new File(fichierOutput);
	    try (BufferedWriter bw = new BufferedWriter(new FileWriter(fichierOutput))) {
		//bw.write("digraph " + fichierOutput.split("\\.")[0] + " {");
		
		String nameDigraph = fichierOutput.substring(0, fichierOutput.length() - ".dot".length());
		bw.write("digraph " + nameDigraph + " {");
		bw.newLine();
		for(Sommet s : gdr.graphe) {
		    if(s.voisinsSortants.size() == 0) {
			bw.write(s.id + ";");
			bw.newLine();
		    }
		    else
			for(Sommet vs : s.voisinsSortants) {
			    bw.write(s.id + " -> " + vs.id + ";");
			    bw.newLine();
			}
		    bw.flush();
		}
		bw.write("}");
		bw.newLine();
		bw.flush();
		//bw.close(); //Déjà géré par le try-with-resources => AutoCloseable
	    } catch(IOException e) { System.out.println("Erreur lors de l'écriture :\n" + e); }
	} //fin else args.length
    } //fin main


}
